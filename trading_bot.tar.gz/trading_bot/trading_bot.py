
# trading_bot.py

import pandas as pd
import time
import logging
from config import exchange, symbol, interval, amount_per_trade, grid_levels, grid_size, trailing_sell_percent
from ml_model import predict_trend

logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0

def check_usdt_balance():
    balance = exchange.fetch_balance()
    usdt_balance = balance.get('total', {}).get('USDT', 0)
    if usdt_balance < amount_per_trade * grid_levels:
        logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
        return False
    else:
        logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
        return True

def fetch_data():
    ohlcv = exchange.fetch_ohlcv(symbol, interval)
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df

def calculate_rsi(df, period=14):
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def place_grid_orders(df):
    last_price = df['close'].iloc[-1]
    grid_prices = [last_price * (1 + grid_size * i) for i in range(-grid_levels, grid_levels + 1)]
    for price in grid_prices:
        logging.info(f"Grid order ditempatkan pada harga: {price:.4f} USDT")

def trailing_sell(last_price, highest_price, entry_price):
    sell_trigger_price = highest_price * (1 - trailing_sell_percent)
    if last_price < sell_trigger_price:
        logging.info(f"Trailing sell triggered at {last_price:.4f} USDT.")
        return True
    return False

def main():
    global total_profit
    if not check_usdt_balance():
        return

    logging.info("Memulai bot trading untuk pasangan %s", symbol)
    entry_price = None
    highest_price = 0

    while True:
        try:
            df = fetch_data()
            df['RSI'] = calculate_rsi(df)

            # Machine learning model prediction
            predicted_trend = predict_trend(df)

            last_rsi = df['RSI'].iloc[-1]
            last_price = df['close'].iloc[-1]

            if predicted_trend == 'up' and last_rsi < 30:
                logging.info(f"Membeli pada harga {last_price:.4f} USDT dengan RSI {last_rsi:.2f}")
                entry_price = last_price
                highest_price = last_price
                place_grid_orders(df)
            elif predicted_trend == 'down' or trailing_sell(last_price, highest_price, entry_price):
                profit = last_price - entry_price if entry_price else 0
                total_profit += profit
                logging.info(f"Menjual pada harga {last_price:.4f} USDT dengan RSI {last_rsi:.2f}. Profit: {profit:.4f} USDT")
                logging.info(f"Total Profit Keseluruhan: {total_profit:.4f} USDT")
                entry_price = None

            if entry_price and last_price > highest_price:
                highest_price = last_price

            time.sleep(10)

        except ccxt.BaseError as e:
            logging.error(f"Kesalahan pada API Exchange: {str(e)}")
            time.sleep(5)

if __name__ == "__main__":
    main()
