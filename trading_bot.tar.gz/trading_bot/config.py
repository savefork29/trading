
# config.py

import ccxt

exchange = ccxt.tokocrypto({
    'apiKey': 'your_api_key',
    'secret': 'your_secret_key',
})

symbol = 'BNB/USDT'
interval = '5m'
amount_per_trade = 0.001
grid_levels = 5
grid_size = 0.01
trailing_sell_percent = 0.015
