# Konfigurasi untuk Bot Trading

# API Key dan Secret Key untuk akses ke Tokocrypto
API_KEY = 'your_api_key_here'
SECRET_KEY = 'your_secret_key_here'

# Pasangan mata uang yang akan diperdagangkan (misalnya BTC/USDT)
PAIR = 'BTC/USDT'

# Parameter untuk model LSTM
LOOK_BACK = 60  # Jumlah periode yang digunakan untuk prediksi
EPOCHS = 10  # Jumlah epoch untuk pelatihan model LSTM
BATCH_SIZE = 32  # Ukuran batch untuk pelatihan model LSTM

# Parameter untuk indikator teknikal
MA_SHORT_WINDOW = 10  # Window untuk moving average pendek
MA_LONG_WINDOW = 50  # Window untuk moving average panjang
RSI_WINDOW = 14  # Window untuk indikator RSI

# Grid Trading Parameters
GRID_SIZE = 1  # Ukuran grid dalam persentase
GRID_LEVELS = 5  # Jumlah level grid yang ingin ditempatkan

# Trailing Stoploss Parameters
SELL_LO = -40  # Persentase untuk sell-lo (stoploss)
SELL_HI = 200  # Sell profit level (take profit) dalam persen

# Max P/L yang tercapai
MAX_PL = 0  # P/L maksimum yang tercapai
