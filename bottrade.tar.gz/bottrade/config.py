# File: config.py

# Pengaturan API Tokocrypto
API_KEY = 'API_KEY_ANDA'
SECRET_KEY = 'SECRET_KEY_ANDA'

# Pengaturan pasangan trading
PAIR = 'BTC/USDT'

# Parameter Model LSTM
LOOK_BACK = 60
EPOCHS = 25
BATCH_SIZE = 32

# Pengaturan Grid Trading
GRID_LEVELS = 10  # Jumlah level grid
GRID_SIZE = 50  # Jarak antar level dalam USDT

# Parameter Indikator Teknikal
MA_SHORT_WINDOW = 5
MA_LONG_WINDOW = 20
RSI_WINDOW = 14
