# File: main.py

import numpy as np
import pandas as pd
import ccxt
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential
from keras.layers import LSTM, Dense, Dropout
from ta.trend import MACD
from ta.momentum import RSIIndicator
import config  # Mengimpor file konfigurasi

# Inisialisasi API Tokocrypto
exchange = ccxt.tokocrypto({
    'apiKey': config.API_KEY,
    'secret': config.SECRET_KEY,
})

# Mengambil data pasar dan mengubahnya menjadi DataFrame
ohlcv = exchange.fetch_ohlcv(config.PAIR, timeframe='1h', limit=500)
df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])

# ----------------------------------------------
# Bagian 1: Model LSTM untuk Prediksi Harga
# ----------------------------------------------
# Preprocessing data
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(df['close'].values.reshape(-1, 1))

# Menyiapkan data untuk LSTM
X, y = [], []
for i in range(config.LOOK_BACK, len(scaled_data)):
    X.append(scaled_data[i-config.LOOK_BACK:i, 0])
    y.append(scaled_data[i, 0])
X, y = np.array(X), np.array(y)
X = np.reshape(X, (X.shape[0], X.shape[1], 1))

# Membangun model LSTM
model = Sequential()
model.add(LSTM(units=50, return_sequences=True, input_shape=(X.shape[1], 1)))
model.add(Dropout(0.2))
model.add(LSTM(units=50, return_sequences=False))
model.add(Dropout(0.2))
model.add(Dense(units=1))

model.compile(optimizer='adam', loss='mean_squared_error')
model.fit(X, y, epochs=config.EPOCHS, batch_size=config.BATCH_SIZE)

# Menggunakan model untuk prediksi harga
predictions = model.predict(X)
predictions = scaler.inverse_transform(predictions)

# ----------------------------------------------
# Bagian 2: Menambahkan Indikator Teknikal
# ----------------------------------------------
# Menghitung indikator Moving Averages, RSI, dan MACD
df['ma_short'] = df['close'].rolling(window=config.MA_SHORT_WINDOW).mean()
df['ma_long'] = df['close'].rolling(window=config.MA_LONG_WINDOW).mean()

rsi = RSIIndicator(close=df['close'], window=config.RSI_WINDOW)
df['rsi'] = rsi.rsi()

macd = MACD(close=df['close'])
df['macd'] = macd.macd()
df['macd_signal'] = macd.macd_signal()

# ----------------------------------------------
# Bagian 3: Strategi Grid Trading
# ----------------------------------------------
base_price = exchange.fetch_ticker(config.PAIR)['last']
max_pl = 0  # Maximum Profit/Loss

# Fungsi untuk menghitung trailing stoploss
def calculate_trailing_stoploss(max_pl, initial_sell_lo):
    if max_pl > 0:
        # Formula untuk menghitung trailing stoploss
        new_sell_lo = (100 + initial_sell_lo) * (100 + max_pl) / 100 - 100
        return new_sell_lo
    return initial_sell_lo

def place_grid_orders():
    global max_pl  # Menggunakan variabel max_pl global
    
    balance = exchange.fetch_balance()
    available_balance = balance['free']['USDT']  # atau sesuai dengan aset yang Anda miliki
    
    # Cek apakah saldo cukup untuk minimal order
    if available_balance < config.MIN_ORDER_USDT:
        print(f"Saldo tidak cukup untuk menempatkan order. Saldo tersedia: {available_balance} USDT. Minimal order adalah {config.MIN_ORDER_USDT} USDT.")
        return
    
    ticker = exchange.fetch_ticker(config.PAIR)
    price = ticker['last']  # Mengambil harga pasar saat ini
    
    # Menghitung jumlah minimal yang dapat dibeli untuk mencapai minimal order
    min_amount = config.MIN_ORDER_USDT / price
    print(f"Jumlah minimal yang dibeli: {min_amount} {config.PAIR.split('/')[0]}")

    for i in range(1, config.GRID_LEVELS + 1):
        buy_price = base_price - (i * config.GRID_SIZE)
        sell_price = base_price + (i * config.GRID_SIZE)
        
        try:
            # Pastikan jumlah order beli tidak lebih kecil dari jumlah minimal
            if min_amount >= (0.01):  # Menggunakan 0.01 sebagai jumlah minimal yang disarankan
                exchange.create_limit_buy_order(config.PAIR, min_amount, buy_price)
                exchange.create_limit_sell_order(config.PAIR, min_amount, sell_price)
                print(f"Order beli di {buy_price} dan jual di {sell_price} berhasil ditempatkan.")
            else:
                print(f"Jumlah beli tidak memenuhi minimal order untuk level {i}.")
        except Exception as e:
            print(f"Error saat menempatkan order pada level {i}: {str(e)}")
            continue

    print(f"{config.GRID_LEVELS} order beli dan jual berhasil ditempatkan di grid.")

def update_stoploss_based_on_pl():
    global max_pl
    current_price = exchange.fetch_ticker(config.PAIR)['last']
    current_pl = (current_price - base_price) / base_price * 100  # Menghitung P/L saat ini
    
    if current_pl > max_pl:
        max_pl = current_pl
        # Update sell-lo menggunakan trailing stoploss
        new_sell_lo = calculate_trailing_stoploss(max_pl, config.SELL_LO)
        print(f"P/L mencapai {max_pl}%. Sell-lo diperbarui menjadi {new_sell_lo}%")
        # Update stoploss dengan nilai yang baru (sel-lo yang telah dihitung)
        # Misalnya, untuk order jual:
        exchange.create_limit_sell_order(config.PAIR, 0.01, current_price * (1 - new_sell_lo / 100))

# ----------------------------------------------
# Logika Trading Menggabungkan Semua Komponen
# ----------------------------------------------
def execute_trading_strategy():
    try:
        # Prediksi harga dari LSTM
        latest_prediction = predictions[-1, 0]
        print(f"Prediksi harga terakhir: {latest_prediction}")

        # Logika menggunakan indikator teknikal
        if df['ma_short'].iloc[-1] > df['ma_long'].iloc[-1] and df['rsi'].iloc[-1] < 70:
            print("Sinyal Beli berdasarkan MA dan RSI")
            # Tambahkan logika untuk order beli
        elif df['ma_short'].iloc[-1] < df['ma_long'].iloc[-1] and df['rsi'].iloc[-1] > 30:
            print("Sinyal Jual berdasarkan MA dan RSI")
            # Tambahkan logika untuk order jual

        # Menempatkan order grid
        place_grid_orders()

        # Perbarui stoploss berdasarkan P/L yang tercapai
        update_stoploss_based_on_pl()

    except Exception as e:
        print(f"Terjadi kesalahan dalam menjalankan strategi trading: {str(e)}")

# Jalankan strategi trading
execute_trading_strategy()
