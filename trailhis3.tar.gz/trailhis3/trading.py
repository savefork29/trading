import pandas as pd
import time
import logging
import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import joblib
from config import (
    exchange, PAIR_SYMBOL, interval, amount_per_trade, grid_levels, grid_size,
    trailing_sell_percent, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED,
    INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT
)
from ml_model import calculate_indicators, train_svm_model, train_nn_model, load_models, save_models, predict_direction_combined

# Mengatur logging
logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0

def calculate_new_sell_lo(initial_lo, max_pl):
    return (1 + initial_lo / 100) * (1 + max_pl / 100) - 1

def check_usdt_balance():
    balance = exchange.fetch_balance()
    usdt_balance = balance.get('total', {}).get('USDT', 0)
    if usdt_balance < amount_per_trade * grid_levels:
        logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
        return False
    else:
        logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
        return True

def fetch_data():
    ohlcv = exchange.fetch_ohlcv(PAIR_SYMBOL, interval)
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df

def trailing_sell(last_price, highest_price, entry_price, initial_sell_lo):
    max_pl = (highest_price - entry_price) / entry_price * 100
    new_trailing_percent = calculate_new_sell_lo(initial_sell_lo, max_pl)

    # Jual jika harga turun melebihi persentase trailing sell yang baru
    if last_price <= entry_price * (1 - new_trailing_percent / 100):
        return True
    return False

def place_order(order_type, amount):
    try:
        if order_type == 'buy':
            order = exchange.create_market_buy_order(PAIR_SYMBOL, amount)
            logging.info(f"Order beli ditempatkan: {order}")
        elif order_type == 'sell':
            order = exchange.create_market_sell_order(PAIR_SYMBOL, amount)
            logging.info(f"Order jual ditempatkan: {order}")
    except Exception as e:
        logging.error(f"Gagal menempatkan order {order_type}: {e}")

def main():
    global total_profit
    if not check_usdt_balance():
        return

    # Memuat model SVM dan NN yang telah dilatih
    model_svm, scaler_svm, model_nn, scaler_nn = load_models()

    while True:
        try:
            df = fetch_data()
            df = calculate_indicators(df)

            # Jika model tidak ditemukan, latih ulang model
            if model_svm is None or model_nn is None:
                logging.info("Model tidak ditemukan, melatih model baru...")
                model_svm, scaler_svm = train_svm_model(df)
                model_nn, scaler_nn = train_nn_model(df)
                save_models(model_svm, scaler_svm, model_nn, scaler_nn)
                continue

            # Prediksi arah pasar dengan model yang sudah dilatih
            direction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df)

            # Eksekusi order berdasarkan prediksi arah
            if direction == 1:  # Jika prediksi naik
                place_order('buy', amount_per_trade)
            elif direction == 0:  # Jika prediksi turun
                place_order('sell', amount_per_trade)

            # Tunggu 1 menit sebelum iterasi berikutnya
            time.sleep(60)

        except Exception as e:
            logging.error(f"Terjadi kesalahan: {e}")
            time.sleep(60)  # Tunggu sebelum mencoba lagi

if __name__ == '__main__':
    main()

