import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from tensorflow import keras

# Menghitung indikator teknis yang diperlukan
def calculate_indicators(df):
    df['RSI'] = compute_rsi(df['close'])
    df['ATR'] = compute_atr(df)
    df['UpperBand'], df['LowerBand'] = compute_bollinger_bands(df['close'])
    df['ADX'] = compute_adx(df)
    return df

def compute_rsi(close, period=14):
    delta = close.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def compute_atr(df, period=14):
    df['high_low'] = df['high'] - df['low']
    df['high_close'] = abs(df['high'] - df['close'].shift())
    df['low_close'] = abs(df['low'] - df['close'].shift())
    true_range = df[['high_low', 'high_close', 'low_close']].max(axis=1)
    atr = true_range.rolling(window=period).mean()
    return atr

def compute_bollinger_bands(close, window=20, num_std_dev=2):
    rolling_mean = close.rolling(window=window).mean()
    rolling_std = close.rolling(window=window).std()
    upper_band = rolling_mean + (rolling_std * num_std_dev)
    lower_band = rolling_mean - (rolling_std * num_std_dev)
    return upper_band, lower_band

def compute_adx(df, period=14):
    adx = pd.Series(np.random.rand(len(df)), index=df.index)  # Contoh dummy
    return adx

def train_svm_model(data):
    if data.empty or any(col not in data.columns for col in ['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']):
        raise ValueError("Data tidak lengkap untuk melatih model SVM")

    X = data[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']].dropna()
    y = np.where(data['close'].shift(-1) > data['close'], 1, 0)
    y = pd.Series(y[:len(X)])  # Menjaga panjang y agar sesuai dengan X

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
    model = SVC(probability=True)
    model.fit(X_train, y_train)

    return model, scaler

def train_nn_model(data):
    if data.empty or any(col not in data.columns for col in ['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']):
        raise ValueError("Data tidak lengkap untuk melatih model Neural Network")

    X = data[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']].dropna()
    y = np.where(data['close'].shift(-1) > data['close'], 1, 0)
    y = pd.Series(y[:len(X)])  # Menjaga panjang y agar sesuai dengan X

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    model = keras.Sequential([
        keras.layers.Dense(50, activation='relu', input_shape=(X_train.shape[1],)),
        keras.layers.Dense(25, activation='relu'),
        keras.layers.Dense(1, activation='sigmoid')
    ])
    
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    model.fit(X_train, y_train, epochs=100, batch_size=10, verbose=0)

    return model, scaler

def load_models():
    try:
        model_svm = joblib.load('svm_model.joblib')
        scaler_svm = joblib.load('svm_scaler.joblib')
    except FileNotFoundError:
        model_svm, scaler_svm = None, None

    try:
        model_nn = keras.models.load_model('nn_model.h5')
        scaler_nn = joblib.load('nn_scaler.joblib')
    except Exception:
        model_nn, scaler_nn = None, None

    return model_svm, scaler_svm, model_nn, scaler_nn

def save_models(model_svm, scaler_svm, model_nn, scaler_nn):
    joblib.dump(model_svm, 'svm_model.joblib')
    joblib.dump(scaler_svm, 'svm_scaler.joblib')
    model_nn.save('nn_model.h5')
    joblib.dump(scaler_nn, 'nn_scaler.joblib')

def predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df):
    last_data = df[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']].iloc[-1:].dropna()
    if last_data.empty:
        return None

    last_data_scaled = scaler_svm.transform(last_data)

    svm_prediction = model_svm.predict(last_data_scaled)
    nn_prediction = (model_nn.predict(scaler_nn.transform(last_data)).flatten() > 0.5).astype(int)

    combined_prediction = np.mean([svm_prediction, nn_prediction])
    return 1 if combined_prediction > 0.5 else 0
