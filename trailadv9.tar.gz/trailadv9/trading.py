import pandas as pd
import time
import logging
from config import (
    exchange, PAIR_SYMBOL, interval, amount_per_trade, grid_levels, grid_size,
    trailing_sell_percent, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED,
    INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT
)
from ml_model import train_svm_model, train_nn_model, load_trained_models, predict_direction_combined, calculate_indicators

# Inisialisasi logging dengan level logging informasi
logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0

def check_usdt_balance():
    try:
        balance = exchange.fetch_balance()
        usdt_balance = balance.get('total', {}).get('USDT', 0)
        if usdt_balance < amount_per_trade * grid_levels:
            logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
            return False
        else:
            logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
            return True
    except Exception as e:
        logging.error(f"Error checking USDT balance: {e}")
        return False

def fetch_data():
    try:
        ohlcv = exchange.fetch_ohlcv(PAIR_SYMBOL, interval)
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        return df
    except Exception as e:
        logging.error(f"Error fetching data: {e}")
        return pd.DataFrame()  # Mengembalikan DataFrame kosong jika terjadi error

def calculate_rsi(df, period=14):
    try:
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    except Exception as e:
        logging.error(f"Error calculating RSI: {e}")
        return pd.Series([])  # Mengembalikan Series kosong jika terjadi error

def place_grid_orders(df):
    try:
        last_price = df['close'].iloc[-1]
        grid_prices = [last_price * (1 + grid_size * i) for i in range(-grid_levels, grid_levels + 1)]
        for price in grid_prices:
            logging.info(f"Grid order ditempatkan pada harga: {price:.4f} USDT")
    except Exception as e:
        logging.error(f"Error placing grid orders: {e}")

def trailing_sell(last_price, highest_price, entry_price):
    try:
        if ENABLE_TRAILING_SELL_ADVANCED:
            adjusted_trailing_percent = trailing_sell_percent + TRAILING_SELL_ADJUSTMENT
            sell_trigger_price = highest_price * (1 - adjusted_trailing_percent)
        else:
            sell_trigger_price = highest_price * (1 - trailing_sell_percent)

        if last_price < sell_trigger_price:
            logging.info(f"Trailing sell triggered at {last_price:.4f} USDT. Selling...")
            # Eksekusi pesanan jual
            try:
                exchange.create_market_sell_order(PAIR_SYMBOL, amount_per_trade)
                logging.info(f"Sell order executed at price: {last_price:.4f} USDT.")
                return True  # Menunjukkan bahwa pesanan jual telah dipicu
            except Exception as e:
                logging.error(f"Error executing sell order: {e}")
                return False  # Tidak ada pesanan jual yang dipicu
        return False  # Tidak ada pesanan jual yang dipicu
    except Exception as e:
        logging.error(f"Error in trailing sell logic: {e}")
        return False

def main():
    try:
        # Memuat model yang sudah dilatih atau melatih model baru jika belum tersedia
        model_svm, scaler_svm, model_nn, scaler_nn = load_trained_models()
        if model_svm is None or model_nn is None:
            logging.info("Model tidak ditemukan. Melatih model baru...")
            data = fetch_data()
            
            # Log pelatihan model SVM
            logging.info("Memulai pelatihan model SVM...")
            model_svm, scaler_svm = train_svm_model(data)
            logging.info("Pelatihan model SVM selesai.")
            
            # Log pelatihan model Neural Network
            logging.info("Memulai pelatihan model Neural Network...")
            model_nn, scaler_nn = train_nn_model(data)
            logging.info("Pelatihan model Neural Network selesai.")
        else:
            logging.info("Model yang ada telah dimuat.")

        # Cek saldo USDT
        if not check_usdt_balance():
            return

        highest_price = 0
        entry_price = 0

        while True:
            df = fetch_data()
            if df.empty:
                logging.error("Tidak ada data yang diperoleh. Mencoba kembali...")
                time.sleep(60)
                continue

            last_price = df['close'].iloc[-1]
            rsi = calculate_rsi(df)

            # Update harga tertinggi untuk logika trailing sell
            highest_price = max(highest_price, last_price)

            # Prediksi arah harga
            combined_prediction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df)

            if combined_prediction is not None:
                if combined_prediction == 1 and entry_price == 0:  # Sinyal beli dan tidak ada posisi saat ini
                    logging.info(f"Sinyal beli terdeteksi pada harga: {last_price:.4f} USDT. Menempatkan pesanan beli...")
                    try:
                        exchange.create_market_buy_order(PAIR_SYMBOL, amount_per_trade)
                        entry_price = last_price  # Update entry price setelah berhasil beli
                        logging.info(f"Pesanan beli dieksekusi pada harga: {last_price:.4f} USDT.")
                    except Exception as e:
                        logging.error(f"Error executing buy order: {e}")

                elif combined_prediction == 0 and entry_price > 0:  # Sinyal jual dan posisi saat ini ada
                    if trailing_sell(last_price, highest_price, entry_price):
                        entry_price = 0  # Reset entry price setelah jual

            # Tidur selama interval
            time.sleep(60)  # Sesuaikan waktu tidur sesuai dengan interval Anda

    except Exception as e:
        logging.error(f"Error tak terduga dalam main loop: {e}")

if __name__ == "__main__":
    main()
