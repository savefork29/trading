import os
from dotenv import load_dotenv

# Memuat variabel lingkungan dari file .env jika ada
load_dotenv()

# Token bot Telegram
BOT_TOKEN = os.getenv("BOT_TOKEN")

# Admin Telegram ID
ADMIN_TELEGRAM_ID = os.getenv("ADMIN_TELEGRAM_ID")

# Wallet bot (untuk menerima deposit)
OWNER_WALLET_ADDRESS = os.getenv("OWNER_WALLET_ADDRESS")

# Seed phrase untuk wallet bot (digunakan untuk menghasilkan private key)
SEED_PHRASE = os.getenv("SEED_PHRASE")

# URL Node Axiome Chain
AXIOME_NODE_URL = "https://api-chain.axiomechain.org"

# API Harga AXM (gunakan CoinGecko atau platform lain yang mendukung)
AXM_PRICE_API_URL = "https://api.coingecko.com/api/v3/simple/price?ids=axiome&vs_currencies=usd"

# Komisi transaksi (%)
TRANSACTION_FEE_PERCENTAGE = 1.0  # 1%
