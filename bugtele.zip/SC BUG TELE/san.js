const settings = {
  token: '7904974172:AAEWc6prbAokEiRF_4ZLFt5ioKbfVA',// Token Bot panel dan domain
  adminId: '6791166535',
  urladmin: 'https://t.me/Nanzzxbotz',
  domain: 'https://willstore.mypanel-ku.my.id', // Isi dengan domain yang digunakan
  plta: 'ptla_D2wifDmipOR3ZacvKGcP9F76cTU3pMdAAe03rag5syK', // Isi dengan nilai plta yang sesuai
  pltc: 'ptlc_7wCJMLlVBCkt7LMQQTGDF8drxnTzp6h9aa5Zo0Vz5f0', // Isi dengan nilai pltc yang sesuai
  pp: 'https://tmpfiles.org/dl/14426067/1729079343765.jpg',
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;