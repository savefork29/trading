import numpy as np
import pandas as pd
import ccxt
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential
from keras.layers import LSTM, Dense, Dropout
from ta.trend import MACD
from ta.momentum import RSIIndicator
import config  # Mengimpor file konfigurasi
import time

# Inisialisasi API Tokocrypto
exchange = ccxt.tokocrypto({
    'apiKey': config.API_KEY,
    'secret': config.SECRET_KEY,
})

# ----------------------------------------------
# Fungsi untuk Mengambil Data Pasar
# ----------------------------------------------
def fetch_market_data():
    try:
        ohlcv = exchange.fetch_ohlcv(config.PAIR, timeframe='1h', limit=500)
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        return df
    except Exception as e:
        print(f"Kesalahan saat mengambil data pasar: {str(e)}")
        return None

# ----------------------------------------------
# Bagian 1: Model LSTM untuk Prediksi Harga
# ----------------------------------------------
def train_lstm_model(df):
    # Preprocessing data
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(df['close'].values.reshape(-1, 1))

    # Menyiapkan data untuk LSTM
    X, y = [], []
    for i in range(config.LOOK_BACK, len(scaled_data)):
        X.append(scaled_data[i-config.LOOK_BACK:i, 0])
        y.append(scaled_data[i, 0])
    X, y = np.array(X), np.array(y)
    X = np.reshape(X, (X.shape[0], X.shape[1], 1))

    # Membangun model LSTM
    model = Sequential()
    model.add(LSTM(units=50, return_sequences=True, input_shape=(X.shape[1], 1)))
    model.add(Dropout(0.2))
    model.add(LSTM(units=50, return_sequences=False))
    model.add(Dropout(0.2))
    model.add(Dense(units=1))

    model.compile(optimizer='adam', loss='mean_squared_error')
    model.fit(X, y, epochs=config.EPOCHS, batch_size=config.BATCH_SIZE)

    return model, scaler

# ----------------------------------------------
# Bagian 2: Menambahkan Indikator Teknikal
# ----------------------------------------------
def add_technical_indicators(df):
    df['ma_short'] = df['close'].rolling(window=config.MA_SHORT_WINDOW).mean()
    df['ma_long'] = df['close'].rolling(window=config.MA_LONG_WINDOW).mean()
    rsi = RSIIndicator(close=df['close'], window=config.RSI_WINDOW)
    df['rsi'] = rsi.rsi()
    macd = MACD(close=df['close'])
    df['macd'] = macd.macd()
    df['macd_signal'] = macd.macd_signal()
    return df

# ----------------------------------------------
# Bagian 3: Strategi Grid Trading
# ----------------------------------------------
base_price = exchange.fetch_ticker(config.PAIR)['last']
max_pl = 0  # Maximum Profit/Loss

def calculate_trailing_stoploss(max_pl, initial_sell_lo):
    if max_pl > 0:
        new_sell_lo = (100 + initial_sell_lo) * (100 + max_pl) / 100 - 100
        return new_sell_lo
    return initial_sell_lo

def place_grid_orders():
    global max_pl
    balance = exchange.fetch_balance()
    available_balance = balance['free']['USDT']
    
    if available_balance < 0.01:
        print(f"Saldo tidak cukup untuk menempatkan order grid. Saldo tersedia: {available_balance} USDT.")
        return
    
    for i in range(1, config.GRID_LEVELS + 1):
        buy_price = base_price - (i * config.GRID_SIZE)
        sell_price = base_price + (i * config.GRID_SIZE)
        try:
            exchange.create_limit_buy_order(config.PAIR, 0.01, buy_price)
            exchange.create_limit_sell_order(config.PAIR, 0.01, sell_price)
            print(f"Order beli di {buy_price} dan jual di {sell_price} berhasil ditempatkan.")
        except Exception as e:
            print(f"Error saat menempatkan order pada level {i}: {str(e)}")
            continue

    print(f"{config.GRID_LEVELS} order beli dan jual berhasil ditempatkan di grid.")

def update_stoploss_based_on_pl():
    global max_pl
    current_price = exchange.fetch_ticker(config.PAIR)['last']
    current_pl = (current_price - base_price) / base_price * 100
    
    if current_pl > max_pl:
        max_pl = current_pl
        new_sell_lo = calculate_trailing_stoploss(max_pl, config.SELL_LO)
        print(f"P/L mencapai {max_pl}%. Sell-lo diperbarui menjadi {new_sell_lo}%")
        exchange.create_limit_sell_order(config.PAIR, 0.01, current_price * (1 - new_sell_lo / 100))

# ----------------------------------------------
# Logika Trading Menggabungkan Semua Komponen
# ----------------------------------------------
def is_trending_market(df):
    if df['ma_short'].iloc[-1] > df['ma_long'].iloc[-1] and df['rsi'].iloc[-1] < 70:
        print("Pasar dalam tren naik")
        return True
    elif df['ma_short'].iloc[-1] < df['ma_long'].iloc[-1] and df['rsi'].iloc[-1] > 30:
        print("Pasar dalam tren turun")
        return True
    else:
        print("Pasar dalam kondisi sideways")
        return False

def execute_trading_strategy():
    global base_price, max_pl

    # Latih model LSTM (hanya dilakukan satu kali)
    df = fetch_market_data()
    if df is None:
        print("Gagal mengambil data awal. Bot berhenti.")
        return

    model, scaler = train_lstm_model(df)

    while True:  # Loop tak berujung untuk menjalankan strategi
        try:
            # Ambil data pasar terbaru
            df = fetch_market_data()
            if df is None:
                time.sleep(60)
                continue
            
            df = add_technical_indicators(df)
            scaled_data = scaler.transform(df['close'].values.reshape(-1, 1))
            X = [scaled_data[-config.LOOK_BACK:].reshape(-1, 1)]
            X = np.array(X)
            X = np.reshape(X, (X.shape[0], X.shape[1], 1))
            
            # Prediksi harga menggunakan model LSTM
            latest_prediction = model.predict(X)[0, 0]
            latest_prediction = scaler.inverse_transform([[latest_prediction]])[0, 0]
            print(f"Prediksi harga terakhir: {latest_prediction}")

            # Deteksi kondisi pasar
            trending = is_trending_market(df)
            if trending:
                pass  # Logika beli/jual berdasarkan tren dapat ditambahkan di sini
            else:
                place_grid_orders()

            update_stoploss_based_on_pl()
            time.sleep(300)  # Tunggu 5 menit sebelum iterasi berikutnya

        except Exception as e:
            print(f"Terjadi kesalahan dalam menjalankan strategi trading: {str(e)}")
            time.sleep(60)  # Tunggu 1 menit sebelum mencoba lagi

# Jalankan strategi trading
execute_trading_strategy()
