# Pengaturan API untuk akses ke exchange
API_KEY = 'your_api_key'
SECRET_KEY = 'your_secret_key'
PAIR = 'USDT/BTC'  # Ganti dengan pasangan mata uang yang Anda tradingkan

# Parameter LSTM
LOOK_BACK = 60  # Jumlah data yang digunakan untuk melatih model
EPOCHS = 10  # Jumlah epoch untuk training model LSTM
BATCH_SIZE = 32  # Ukuran batch untuk training

# Parameter Moving Averages
MA_SHORT_WINDOW = 50  # Window untuk MA jangka pendek
MA_LONG_WINDOW = 200  # Window untuk MA jangka panjang

# Parameter RSI
RSI_WINDOW = 14  # Window untuk RSI

# Parameter MACD
MACD_FAST_PERIOD = 12
MACD_SLOW_PERIOD = 26
MACD_SIGNAL_PERIOD = 9

# Parameter Grid Trading
GRID_LEVELS = 5  # Jumlah level grid
GRID_SIZE = 0.01  # Ukuran grid dalam persentase dari harga

# Parameter Trailing Stoploss
SELL_LO = -40  # Level stop loss awal (misalnya -40% sebagai awal)
SELL_HI = 200  # Target profit untuk take profit (misalnya +200%)
TRAILING_STOPLOSS_ENABLED = True  # Mengaktifkan trailing stoploss
TRAILING_STOPLOSS_SENSITIVITY = 1.5  # Sensitivitas trailing stoploss terhadap perubahan harga
