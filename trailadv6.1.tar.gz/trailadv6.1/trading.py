import pandas as pd
import time
import logging
from config import (
    exchange, PAIR_SYMBOL, interval, amount_per_trade, grid_levels, grid_size,
    trailing_sell_percent, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED,
    INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT
)
from ml_model import train_svm_model, train_nn_model, predict_direction_combined, calculate_indicators

logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0

def check_usdt_balance():
    balance = exchange.fetch_balance()
    usdt_balance = balance.get('total', {}).get('USDT', 0)
    if usdt_balance < amount_per_trade * grid_levels:
        logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
        return False
    else:
        logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
        return True

def fetch_data():
    ohlcv = exchange.fetch_ohlcv(PAIR_SYMBOL, interval)
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df

def calculate_rsi(df, period=14):
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def place_grid_orders(df):
    last_price = df['close'].iloc[-1]
    grid_prices = [last_price * (1 + grid_size * i) for i in range(-grid_levels, grid_levels + 1)]
    for price in grid_prices:
        logging.info(f"Grid order ditempatkan pada harga: {price:.4f} USDT")

def trailing_sell(last_price, highest_price, entry_price):
    if ENABLE_TRAILING_SELL_ADVANCED:
        adjusted_trailing_percent = trailing_sell_percent + TRAILING_SELL_ADJUSTMENT
        sell_trigger_price = highest_price * (1 - adjusted_trailing_percent)
    else:
        sell_trigger_price = highest_price * (1 - trailing_sell_percent)
    
    if last_price < sell_trigger_price:
        logging.info(f"Trailing sell triggered at {last_price:.4f} USDT.")
        return True
    return False

def execute_order(order_type, price, amount):
    try:
        logging.info(f"Mencoba untuk melakukan {order_type} order pada harga {price} untuk jumlah {amount}")
        order = exchange.create_order(PAIR_SYMBOL, 'limit', order_type, amount, price)
        logging.info(f"{order_type.capitalize()} order berhasil: {order}")
    except Exception as e:
        logging.error(f"Kesalahan saat mencoba {order_type} order: {e}")

def main():
    global total_profit
    if not check_usdt_balance():
        return

    df = fetch_data()
    df['RSI'] = calculate_rsi(df)
    df = calculate_indicators(df)
    model_svm, scaler_svm = train_svm_model(df)
    model_nn, scaler_nn = train_nn_model(df)

    logging.info("Memulai bot trading untuk pasangan %s", PAIR_SYMBOL)
    entry_price = None
    highest_price = 0

    while True:
        try:
            df = fetch_data()
            df['RSI'] = calculate_rsi(df)
            df = calculate_indicators(df)

            last_price = df['close'].iloc[-1]
            direction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df)
            if direction is not None:
                if direction == 1 and df['RSI'].iloc[-1] < 30:
                    logging.info(f"Membeli pada harga {last_price:.4f} USDT dengan RSI {df['RSI'].iloc[-1]:.2f}")
                    entry_price = last_price
                    highest_price = last_price
                    place_grid_orders(df)
                    execute_order('buy', last_price, amount_per_trade)
                elif direction == 0 and entry_price is not None:
                    logging.info(f"Menjual pada harga {last_price:.4f} USDT dengan profit.")
                    total_profit += (last_price - entry_price) / entry_price * 100
                    logging.info(f"Total profit saat ini: {total_profit:.2f}%")
                    execute_order('sell', last_price, amount_per_trade)
                    entry_price = None
                    highest_price = 0
                elif trailing_sell(last_price, highest_price, entry_price) and entry_price is not None:
                    logging.info(f"Trailing sell pada harga {last_price:.4f} USDT.")
                    total_profit += (last_price - entry_price) / entry_price * 100
                    logging.info(f"Total profit saat ini: {total_profit:.2f}%")
                    execute_order('sell', last_price, amount_per_trade)
                    entry_price = None
                    highest_price = 0

            if entry_price:
                highest_price = max(highest_price, last_price)
            time.sleep(60)

        except Exception as e:
            logging.error(f"Terjadi kesalahan: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()
