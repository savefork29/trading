import ccxt
import time
from config import API_KEY, SECRET_KEY, BASE_SYMBOL, AMOUNT, SHORT_WINDOW, LONG_WINDOW, SLEEP_INTERVAL, PROFIT_IN_USDT
from tensorflow.keras.models import load_model
import numpy as np

# Inisialisasi exchange MEXC menggunakan CCXT
exchange = ccxt.mexc({
    'apiKey': API_KEY,
    'secret': SECRET_KEY,
    'enableRateLimit': True,
})

# Load model LSTM untuk prediksi harga
lstm_model = load_model("lstm_model.h5")

def predict_trend(prices, model):
    # Mengonversi data harga menjadi bentuk input untuk model
    input_data = np.array(prices).reshape((1, len(prices), 1))
    prediction = model.predict(input_data)
    return prediction[0][0]  # Mengembalikan prediksi pertama

def main():
    price_history = []  # Menyimpan data harga untuk prediksi model

    while True:
        try:
            # Ambil data harga terbaru dari pasangan trading
            ticker = exchange.fetch_ticker(BASE_SYMBOL)
            last_price = ticker['close']
            
            # Tambahkan harga terbaru ke dalam daftar historis
            price_history.append(last_price)
            
            # Jika sudah cukup data untuk model, lakukan prediksi
            if len(price_history) >= 50:  # Misalnya perlu 50 data historis
                prices = price_history[-50:]
                predicted_price = predict_trend(prices, lstm_model)
                
                # Logika "reverse" berdasarkan konfigurasi PROFIT_IN_USDT
                if PROFIT_IN_USDT:
                    # Profit dalam USDT: beli saat harga diprediksi naik, jual saat turun
                    if predicted_price > last_price:
                        try:
                            order = exchange.create_market_buy_order(BASE_SYMBOL, AMOUNT)
                            print("Order beli (USDT mode) berhasil:", order)
                        except Exception as e:
                            print("Gagal melakukan order beli:", e)
                    elif predicted_price < last_price:
                        try:
                            order = exchange.create_market_sell_order(BASE_SYMBOL, AMOUNT)
                            print("Order jual (USDT mode) berhasil:", order)
                        except Exception as e:
                            print("Gagal melakukan order jual:", e)
                else:
                    # Profit dalam kripto: jual saat harga diprediksi naik, beli saat turun
                    if predicted_price > last_price:
                        try:
                            order = exchange.create_market_sell_order(BASE_SYMBOL, AMOUNT)
                            print("Order jual (Crypto mode) berhasil:", order)
                        except Exception as e:
                            print("Gagal melakukan order jual:", e)
                    elif predicted_price < last_price:
                        try:
                            order = exchange.create_market_buy_order(BASE_SYMBOL, AMOUNT)
                            print("Order beli (Crypto mode) berhasil:", order)
                        except Exception as e:
                            print("Gagal melakukan order beli:", e)

            # Tunggu sebelum iterasi berikutnya
            time.sleep(SLEEP_INTERVAL)

        except Exception as e:
            print("Error di loop utama:", e)
            time.sleep(SLEEP_INTERVAL)

if __name__ == "__main__":
    main()
