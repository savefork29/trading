# File konfigurasi

API_KEY = 'API_KEY_ANDA'
SECRET_KEY = 'SECRET_KEY_ANDA'
BASE_SYMBOL = 'BTC/USDT'  # Pasangan trading yang digunakan
AMOUNT = 0.001  # Jumlah yang akan dibeli/dijual setiap kali trading
SHORT_WINDOW = 10  # Periode moving average pendek
LONG_WINDOW = 50   # Periode moving average panjang
SLEEP_INTERVAL = 60  # Waktu tunggu antar trading (dalam detik)

# Menentukan apakah ingin profit dalam USDT atau kripto pasangan
PROFIT_IN_USDT = True  # True untuk profit dalam USDT, False untuk profit dalam BTC
