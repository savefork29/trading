import os
import ccxt

# API Key dan Secret Key Tokocrypto
API_KEY = os.getenv('TOKOCRYPTO_API_KEY')
SECRET_KEY = os.getenv('TOKOCRYPTO_SECRET_KEY')

# Konfigurasi trading
PAIR_SYMBOL = 'BNB/USDT'  # Ganti `symbol` dengan `PAIR_SYMBOL` untuk konsistensi
interval = '5m'
amount_per_trade = 0.001
grid_levels = 5
grid_size = 0.01
trailing_sell_percent = 0.015

# Target profit dan trailing sell canggih
TARGET_PROFIT = 10  # Target profit dalam persentase
ENABLE_TRAILING_SELL_ADVANCED = True
INITIAL_SELL_LO = -40  # Stoploss awal dalam persentase
TRAILING_SELL_ADJUSTMENT = 0.2  # Persentase penyesuaian trailing sell

# Inisialisasi exchange Tokocrypto
exchange = ccxt.tokocrypto({
    'apiKey': API_KEY,
    'secret': SECRET_KEY,
})
