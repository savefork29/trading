# trading.py

import logging
import time
import pandas as pd
from binance.client import Client
from config import API_KEY, API_SECRET, PAIR_SYMBOL, TARGET_PROFIT
from ml_model import train_svm_model, train_nn_model, predict_direction_combined, calculate_indicators

logging.basicConfig(level=logging.INFO)

def fetch_data():
    # Ambil data candlestick dari Binance
    client = Client(API_KEY, API_SECRET)
    klines = client.get_klines(symbol=PAIR_SYMBOL, interval=Client.KLINE_INTERVAL_15MINUTE)
    data = pd.DataFrame(klines, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_asset_volume', 'number_of_trades', 'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'])
    data['close'] = data['close'].astype(float)
    data['open'] = data['open'].astype(float)
    data['high'] = data['high'].astype(float)
    data['low'] = data['low'].astype(float)
    data['volume'] = data['volume'].astype(float)
    return data

def main():
    logging.info("Memulai bot trading...")
    client = Client(API_KEY, API_SECRET)

    # Cek saldo USDT
    balance = client.get_asset_balance(asset='USDT')
    if float(balance['free']) < 10:
        logging.warning("Saldo USDT tidak mencukupi.")
        return
    else:
        logging.info(f"Saldo USDT mencukupi: {balance['free']} USDT.")

    # Ambil data dan hitung indikator tambahan
    df = fetch_data()
    df = calculate_indicators(df)

    # Latih model SVM dan Neural Network
    model_svm, scaler_svm = train_svm_model(df)
    model_nn, scaler_nn = train_nn_model(df)

    logging.info("Memulai bot trading untuk pasangan BNB/USDT")
    while True:
        # Ambil data terbaru dan prediksi arah pergerakan harga
        df = fetch_data()
        df = calculate_indicators(df)
        direction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df)

        if direction is None:
            logging.info("Sinyal tidak valid atau kondisi pasar tidak mendukung.")
        elif direction == 1:
            # Melakukan pembelian
            logging.info("Membeli BNB...")
            # Placeholder untuk logika pembelian
            buy_price = df['close'].iloc[-1]
            target_price = buy_price * (1 + TARGET_PROFIT / 100)
            logging.info(f"Dibeli pada harga {buy_price} USDT, menargetkan harga jual {target_price} USDT.")

            # Tunggu hingga mencapai target profit atau kondisi trailing sell
            while True:
                df = fetch_data()
                last_price = df['close'].iloc[-1]

                # Periksa apakah data harga terakhir ada
                if last_price is None or buy_price is None:
                    logging.error("Data harga tidak valid.")
                    break

                if last_price >= target_price:
                    logging.info(f"Menjual pada harga {last_price} USDT dengan profit.")
                    # Placeholder untuk logika penjualan
                    break
                elif last_price < buy_price * 0.98:  # Contoh cut loss pada harga 98% dari harga beli
                    logging.warning(f"Cut loss pada harga {last_price} USDT.")
                    # Placeholder untuk logika penjualan cut loss
                    break

                time.sleep(60)  # Tunggu 1 menit sebelum cek harga kembali

        time.sleep(300)  # Tunggu 5 menit sebelum cek sinyal trading lagi

if __name__ == "__main__":
    main()
