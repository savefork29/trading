import time
import logging
from binance.client import Client
from config import API_KEY, SECRET_KEY, PAIR_SYMBOL, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED, INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT
from ml_model import train_svm_model, train_nn_model, predict_direction_combined, calculate_indicators

# Inisialisasi client Binance
client = Client(API_KEY, SECRET_KEY)

# Konfigurasi logging
logging.basicConfig(level=logging.INFO)

def get_balance(asset):
    balance = client.get_asset_balance(asset=asset)
    return float(balance['free'])

def get_price(symbol):
    ticker = client.get_symbol_ticker(symbol=symbol)
    return float(ticker['price'])

def place_order(symbol, side, quantity):
    try:
        order = client.order_market(symbol=symbol, side=side, quantity=quantity)
        logging.info(f"Order {side} {quantity} {symbol} berhasil.")
        return order
    except Exception as e:
        logging.error(f"Gagal melakukan order: {e}")
        return None

def main():
    logging.info("Memulai bot trading...")

    # Mengecek saldo USDT
    usdt_balance = get_balance('USDT')
    if usdt_balance < 10:
        logging.warning("Saldo USDT tidak mencukupi untuk melakukan trading.")
        return
    logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")

    # Mendapatkan data harga
    logging.info("Menghitung indikator tambahan...")
    df = calculate_indicators(PAIR_SYMBOL)
    logging.info("Indikator tambahan selesai dihitung.")

    # Melatih model SVM dan Neural Network
    logging.info("Melatih model SVM...")
    model_svm, scaler_svm = train_svm_model(df)
    logging.info("Model SVM selesai dilatih.")

    logging.info("Melatih model Neural Network...")
    model_nn, scaler_nn = train_nn_model(df)
    logging.info("Model Neural Network selesai dilatih.")

    # Memulai loop trading
    while True:
        try:
            # Prediksi arah harga
            df = calculate_indicators(PAIR_SYMBOL)
            prediction = predict_direction_combined(df, model_svm, scaler_svm, model_nn, scaler_nn)
            
            # Mendapatkan harga terkini
            current_price = get_price(PAIR_SYMBOL.replace('/', ''))
            logging.info(f"Harga terkini {PAIR_SYMBOL}: {current_price}")

            # Logika trading berdasarkan prediksi dan trailing sell
            if prediction == 1:  # Sinyal beli
                logging.info(f"Melakukan pembelian pada harga {current_price} USDT")
                place_order(PAIR_SYMBOL.replace('/', ''), 'BUY', 0.001)  # Sesuaikan jumlah pembelian
                
                # Menunggu dan memantau trailing sell
                bought_price = current_price
                target_price = bought_price * (1 + TARGET_PROFIT / 100)
                stop_loss_price = bought_price * (1 + INITIAL_SELL_LO / 100)

                while True:
                    current_price = get_price(PAIR_SYMBOL.replace('/', ''))
                    if ENABLE_TRAILING_SELL_ADVANCED:
                        if current_price >= target_price:
                            logging.info(f"Menjual pada harga {current_price} USDT dengan profit.")
                            place_order(PAIR_SYMBOL.replace('/', ''), 'SELL', 0.001)
                            break
                        elif current_price <= stop_loss_price:
                            logging.info(f"Menjual pada harga {current_price} USDT untuk memotong kerugian.")
                            place_order(PAIR_SYMBOL.replace('/', ''), 'SELL', 0.001)
                            break
                        else:
                            target_price -= target_price * TRAILING_SELL_ADJUSTMENT / 100
                    else:
                        if current_price >= target_price:
                            logging.info(f"Menjual pada harga {current_price} USDT dengan profit.")
                            place_order(PAIR_SYMBOL.replace('/', ''), 'SELL', 0.001)
                            break

                    time.sleep(10)

            time.sleep(300)  # Tunggu 5 menit sebelum prediksi berikutnya

        except Exception as e:
            logging.error(f"Terjadi kesalahan: {e}")
            time.sleep(60)

if __name__ == "__main__":
    main()
