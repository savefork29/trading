import pandas as pd
import time
import logging
import asyncio
from config import exchange, PAIR_SYMBOL, interval, TELEGRAM_TOKEN, TELEGRAM_CHAT_ID
from ml_model import train_svm_model, train_nn_model, predict_direction_combined, calculate_indicators
from telegram import Bot

# Inisialisasi Telegram bot
bot = Bot(token=TELEGRAM_TOKEN)

# Logging untuk debugging
logging.basicConfig(level=logging.INFO)
logging.info("Memulai sistem pemberi sinyal...")

def fetch_data():
    ohlcv = exchange.fetch_ohlcv(PAIR_SYMBOL, interval)
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df

def calculate_rsi(df, period=14):
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

async def send_signal(signal_type, price, rsi):
    """
    Mengirimkan sinyal beli/jual melalui Telegram.
    """
    try:
        message = f"Sinyal {signal_type.upper()}:\nHarga: {price:.4f} USDT\nRSI: {rsi:.2f}"
        await bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message)
        logging.info(f"Sinyal {signal_type} terkirim: {message}")
    except Exception as e:
        logging.error(f"Gagal mengirim sinyal {signal_type}: {e}")

async def main():
    df = fetch_data()
    df['RSI'] = calculate_rsi(df)
    df = calculate_indicators(df)
    model_svm, scaler_svm = train_svm_model(df)
    model_nn, scaler_nn = train_nn_model(df)

    logging.info("Memulai pemberi sinyal untuk pasangan %s", PAIR_SYMBOL)

    while True:
        try:
            df = fetch_data()
            df['RSI'] = calculate_rsi(df)
            df = calculate_indicators(df)

            last_price = df['close'].iloc[-1]
            direction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df)
            if direction is not None:
                if direction == 1 and df['RSI'].iloc[-1] < 30:
                    await send_signal('beli', last_price, df['RSI'].iloc[-1])
                elif direction == 0:
                    await send_signal('jual', last_price, df['RSI'].iloc[-1])

            await asyncio.sleep(60)  # Menggunakan asyncio.sleep() alih-alih time.sleep()

        except Exception as e:
            logging.error(f"Terjadi kesalahan: {e}")
            await asyncio.sleep(5)

if __name__ == "__main__":
    # Menjalankan event loop untuk fungsi async main
    asyncio.run(main())
