import os
import ccxt

# API Key dan Secret Key Tokocrypto
API_KEY = os.getenv('TOKOCRYPTO_API_KEY')
SECRET_KEY = os.getenv('TOKOCRYPTO_SECRET_KEY')

# Konfigurasi trading
PAIR_SYMBOL = 'BNB/USDT'  # Ganti `symbol` dengan `PAIR_SYMBOL` untuk konsistensi
symbol = PAIR_SYMBOL  # Alias untuk konsistensi
interval = '5m'
amount_per_trade = 0.001
grid_levels = 5
grid_size = 0.01

# Konfigurasi Telegram
TELEGRAM_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'
TELEGRAM_CHAT_ID = 'YOUR_CHAT_ID'

# Inisialisasi exchange Tokocrypto
exchange = ccxt.tokocrypto({
    'apiKey': API_KEY,
    'secret': SECRET_KEY,
})
