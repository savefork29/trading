import pandas as pd
import time
import logging
from config import (
    exchange, PAIR_SYMBOL, interval, amount_per_trade, grid_levels, grid_size,
    trailing_sell_percent, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED,
    INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT
)
from ml_model import train_svm_model, train_nn_model, predict_direction_combined, calculate_indicators, load_models, save_models

logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0

def calculate_new_sell_lo(initial_lo, max_pl):
    return (1 + initial_lo / 100) * (1 + max_pl / 100) - 1

def check_usdt_balance():
    balance = exchange.fetch_balance()
    usdt_balance = balance.get('total', {}).get('USDT', 0)
    if usdt_balance < amount_per_trade * grid_levels:
        logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
        return False
    else:
        logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
        return True

def fetch_data():
    ohlcv = exchange.fetch_ohlcv(PAIR_SYMBOL, interval)
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df

def trailing_sell(last_price, highest_price, entry_price, initial_sell_lo):
    max_pl = (highest_price - entry_price) / entry_price * 100
    new_trailing_percent = calculate_new_sell_lo(initial_sell_lo, max_pl)
    sell_trigger_price = highest_price * (1 - new_trailing_percent / 100)

    if last_price < sell_trigger_price:
        logging.info(f"Trailing sell triggered at {last_price:.4f} USDT dengan New Sell-lo%: {new_trailing_percent:.2f}%")
        return True
    return False

def execute_order(order_type, price, amount):
    try:
        logging.info(f"Mencoba untuk melakukan {order_type} order pada harga {price} untuk jumlah {amount}")
        order = exchange.create_order(PAIR_SYMBOL, 'limit', order_type, amount, price)
        logging.info(f"{order_type.capitalize()} order berhasil: {order}")
    except Exception as e:
        logging.error(f"Kesalahan saat mencoba {order_type} order: {e}")

def main():
    global total_profit
    if not check_usdt_balance():
        return

    model_svm, scaler_svm, model_nn, scaler_nn = load_models()
    if not model_svm or not model_nn:
        logging.info("Melatih model baru...")
        data = fetch_data()
        model_svm, scaler_svm = train_svm_model(data)
        model_nn, scaler_nn = train_nn_model(data)
        save_models(model_svm, scaler_svm, model_nn, scaler_nn)

    highest_price = 0
    entry_price = 0

    while True:
        data = fetch_data()
        direction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, data)

        if direction == 1:
            last_price = data['close'].iloc[-1]
            if entry_price == 0:  # If we don't have an entry price yet
                execute_order('buy', last_price, amount_per_trade)
                entry_price = last_price
                highest_price = last_price

        elif direction == 0 and entry_price != 0:
            last_price = data['close'].iloc[-1]
            execute_order('sell', last_price, amount_per_trade)
            profit = (last_price - entry_price) / entry_price * 100
            total_profit += profit
            logging.info(f"Sell executed at {last_price}, Profit: {profit:.2f}%")
            entry_price = 0  # Reset entry price after selling

        # Implement trailing sell if enabled
        if ENABLE_TRAILING_SELL_ADVANCED and entry_price != 0:
            last_price = data['close'].iloc[-1]
            if trailing_sell(last_price, highest_price, entry_price, INITIAL_SELL_LO):
                execute_order('sell', last_price, amount_per_trade)
                profit = (last_price - entry_price) / entry_price * 100
                total_profit += profit
                logging.info(f"Trailing sell executed at {last_price}, Profit: {profit:.2f}%")
                entry_price = 0  # Reset entry price after selling

            # Update the highest price
            highest_price = max(highest_price, last_price)

        time.sleep(60)  # Tunggu selama 1 menit sebelum iterasi berikutnya

if __name__ == "__main__":
    main()
