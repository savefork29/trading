import pandas as pd
import numpy as np
import joblib
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam

# Path file untuk menyimpan model
SVM_MODEL_PATH = 'svm_model.joblib'
SVM_SCALER_PATH = 'svm_scaler.joblib'
NN_MODEL_PATH = 'nn_model.h5'
NN_SCALER_PATH = 'nn_scaler.joblib'

# Fungsi untuk menghitung indikator tambahan
def calculate_indicators(data):
    data['ATR'] = data['close'].rolling(window=14).apply(lambda x: x.max() - x.min())
    data['MA20'] = data['close'].rolling(window=20).mean()
    data['UpperBand'] = data['MA20'] + 2 * data['close'].rolling(window=20).std()
    data['LowerBand'] = data['MA20'] - 2 * data['close'].rolling(window=20).std()
    data['ADX'] = data['close'].rolling(window=14).apply(lambda x: (x.diff().abs().sum() / 14) * 100)
    return data

# Fungsi untuk melatih dan menyimpan model SVM
def train_svm_model(data):
    data = calculate_indicators(data)
    data['PriceChange'] = data['close'].diff().shift(-1)
    data['PriceDirection'] = (data['PriceChange'] > 0).astype(int)
    data.dropna(inplace=True)

    # Fitur dan label untuk SVM
    X = data[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']]
    y = data['PriceDirection']

    scaler_svm = StandardScaler()
    X_scaled = scaler_svm.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # Buat dan latih model SVM
    model_svm = SVC(kernel='linear')
    model_svm.fit(X_train, y_train)

    return model_svm, scaler_svm

# Fungsi untuk melatih dan menyimpan model neural network
def train_nn_model(data):
    data = calculate_indicators(data)
    data.dropna(inplace=True)
    scaler_nn = StandardScaler()
    
    # Fitur dan target untuk neural network
    X = data[['open', 'high', 'low', 'close', 'volume', 'RSI', 'ATR', 'ADX']]
    data['target'] = (data['close'].shift(-1) > data['close']).astype(int)
    y = data['target'].dropna()
    
    # Memastikan ukuran yang sama antara X dan y
    min_len = min(len(X), len(y))
    X, y = X[:min_len], y[:min_len]

    X_scaled = scaler_nn.fit_transform(X)

    # Membagi data untuk pelatihan dan pengujian
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # Membangun model neural network sederhana
    model_nn = Sequential([
        Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
        Dropout(0.2),
        Dense(32, activation='relu'),
        Dense(1, activation='sigmoid')
    ])

    model_nn.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])
    model_nn.fit(X_train, y_train, epochs=30, batch_size=16, verbose=1)

    return model_nn, scaler_nn

# Fungsi untuk menyimpan model
def save_models(model_svm, scaler_svm, model_nn, scaler_nn):
    joblib.dump(model_svm, SVM_MODEL_PATH)
    joblib.dump(scaler_svm, SVM_SCALER_PATH)
    model_nn.save(NN_MODEL_PATH)
    joblib.dump(scaler_nn, NN_SCALER_PATH)
    print("Model berhasil disimpan!")

# Fungsi untuk memuat model
def load_models():
    try:
        model_svm = joblib.load(SVM_MODEL_PATH)
        scaler_svm = joblib.load(SVM_SCALER_PATH)
        model_nn = load_model(NN_MODEL_PATH)
        scaler_nn = joblib.load(NN_SCALER_PATH)
        print("Model berhasil dimuat!")
        return model_svm, scaler_svm, model_nn, scaler_nn
    except Exception as e:
        print(f"Gagal memuat model: {e}")
        return None, None, None, None

# Fungsi untuk prediksi arah harga menggunakan kombinasi model
def predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df):
    df = calculate_indicators(df)
    last_rsi = df['RSI'].iloc[-1]
    last_adx = df['ADX'].iloc[-1]

    # Filter tambahan: Hanya prediksi saat ADX cukup kuat
    if last_adx > 20 and (last_rsi < 30 or last_rsi > 70):
        # SVM prediksi
        X_svm = scaler_svm.transform(df[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']].iloc[-1:])
        svm_prediction = model_svm.predict(X_svm)[0]

        # Neural network prediksi
        X_nn = scaler_nn.transform(df[['open', 'high', 'low', 'close', 'volume', 'RSI', 'ATR', 'ADX']].iloc[-1:])
        nn_prediction = model_nn.predict(X_nn)
        nn_prediction = 1 if nn_prediction >= 0.5 else 0

        # Kombinasi prediksi
        combined_prediction = 1 if svm_prediction == 1 and nn_prediction == 1 else 0
        return combined_prediction
    else:
        return None
