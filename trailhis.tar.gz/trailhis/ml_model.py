import pandas as pd
import numpy as np
import joblib
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam
import os

# Path untuk menyimpan model
SVM_MODEL_PATH = 'svm_model.joblib'
SCALER_SVM_PATH = 'scaler_svm.joblib'
NN_MODEL_PATH = 'nn_model.h5'
SCALER_NN_PATH = 'scaler_nn.joblib'

# Fungsi untuk menghitung RSI
def compute_rsi(series, period=14):
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

# Fungsi untuk menghitung ATR
def compute_atr(data, period=14):
    high_low = data['high'] - data['low']
    high_close = abs(data['high'] - data['close'].shift())
    low_close = abs(data['low'] - data['close'].shift())
    true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    return true_range.rolling(window=period).mean()

# Fungsi untuk menghitung indikator
def calculate_indicators(data):
    data['RSI'] = compute_rsi(data['close'])
    data['ATR'] = compute_atr(data)
    # Tambahkan logika untuk menghitung indikator lain sesuai kebutuhan
    return data

# Fungsi untuk menyimpan model dan scaler
def save_models(model_svm, scaler_svm, model_nn, scaler_nn):
    joblib.dump(model_svm, SVM_MODEL_PATH)
    joblib.dump(scaler_svm, SCALER_SVM_PATH)
    model_nn.save(NN_MODEL_PATH)
    joblib.dump(scaler_nn, SCALER_NN_PATH)
    print("Model berhasil disimpan.")

# Fungsi untuk memuat model dan scaler
def load_models():
    try:
        model_svm = joblib.load(SVM_MODEL_PATH)
        scaler_svm = joblib.load(SCALER_SVM_PATH)
        model_nn = load_model(NN_MODEL_PATH)
        scaler_nn = joblib.load(SCALER_NN_PATH)
        print("Model berhasil dimuat.")
        return model_svm, scaler_svm, model_nn, scaler_nn
    except FileNotFoundError as e:
        print(f"Gagal memuat model: {e}")
        return None, None, None, None

# Fungsi untuk melatih model SVM
def train_svm_model(data):
    data = calculate_indicators(data)
    data['PriceChange'] = data['close'].diff().shift(-1)
    data['PriceDirection'] = (data['PriceChange'] > 0).astype(int)
    data.dropna(inplace=True)

    X = data[['close', 'RSI', 'ATR']]
    y = data['PriceDirection']

    scaler_svm = StandardScaler()
    X_scaled = scaler_svm.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    model_svm = SVC(kernel='linear')
    model_svm.fit(X_train, y_train)
    return model_svm, scaler_svm

# Fungsi untuk melatih model neural network
def train_nn_model(data):
    data = calculate_indicators(data)
    data.dropna(inplace=True)
    scaler_nn = StandardScaler()

    X = data[['open', 'high', 'low', 'close', 'volume', 'RSI', 'ATR']]
    data['target'] = (data['close'].shift(-1) > data['close']).astype(int)
    y = data['target'].dropna()

    min_len = min(len(X), len(y))
    X, y = X[:min_len], y[:min_len]
    X_scaled = scaler_nn.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    model_nn = Sequential([
        Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
        Dropout(0.2),
        Dense(32, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    model_nn.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])
    model_nn.fit(X_train, y_train, epochs=30, batch_size=16, verbose=1)

    return model_nn, scaler_nn
