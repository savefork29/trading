import pandas as pd
import time
import logging
import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
import joblib
from config import (
    exchange, PAIR_SYMBOL, interval, amount_per_trade, grid_levels, grid_size,
    trailing_sell_percent, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED,
    INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT
)

# Mengatur logging
logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0

def calculate_new_sell_lo(initial_lo, max_pl):
    return (1 + initial_lo / 100) * (1 + max_pl / 100) - 1

def check_usdt_balance():
    balance = exchange.fetch_balance()
    usdt_balance = balance.get('total', {}).get('USDT', 0)
    if usdt_balance < amount_per_trade * grid_levels:
        logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
        return False
    else:
        logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
        return True

def fetch_data():
    ohlcv = exchange.fetch_ohlcv(PAIR_SYMBOL, interval)
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df

# Fungsi untuk menghitung indikator teknis
def calculate_indicators(df):
    df['RSI'] = compute_rsi(df['close'])
    df['ATR'] = compute_atr(df)
    df['UpperBand'], df['LowerBand'] = compute_bollinger_bands(df['close'])
    df['ADX'] = compute_adx(df)
    return df

def compute_rsi(close, period=14):
    delta = close.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def compute_atr(df, period=14):
    df['high_low'] = df['high'] - df['low']
    df['high_close'] = abs(df['high'] - df['close'].shift())
    df['low_close'] = abs(df['low'] - df['close'].shift())
    true_range = df[['high_low', 'high_close', 'low_close']].max(axis=1)
    atr = true_range.rolling(window=period).mean()
    return atr

def compute_bollinger_bands(close, window=20, num_std_dev=2):
    rolling_mean = close.rolling(window=window).mean()
    rolling_std = close.rolling(window=window).std()
    upper_band = rolling_mean + (rolling_std * num_std_dev)
    lower_band = rolling_mean - (rolling_std * num_std_dev)
    return upper_band, lower_band

def compute_adx(df, period=14):
    adx = pd.Series(np.random.rand(len(df)), index=df.index)  # Contoh dummy
    return adx

# Fungsi pelatihan model SVM
def train_svm_model(data):
    if data.empty or any(col not in data.columns for col in ['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']):
        raise ValueError("Data tidak lengkap untuk melatih model SVM")

    X = data[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']].dropna()
    y = np.where(data['close'].shift(-1) > data['close'], 1, 0)[:-1]
    y = pd.Series(y).iloc[:len(X)]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
    
    model = SVC(probability=True)
    model.fit(X_train, y_train)

    return model, scaler

# Fungsi pelatihan model Neural Network dengan TensorFlow
def train_nn_model(data):
    if data.empty or any(col not in data.columns for col in ['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']):
        raise ValueError("Data tidak lengkap untuk melatih model Neural Network")

    X = data[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']].dropna()
    y = np.where(data['close'].shift(-1) > data['close'], 1, 0)[:-1]
    y = pd.Series(y).iloc[:len(X)]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # Model neural network dengan TensorFlow
    model = Sequential([
        Dense(50, activation='relu', input_shape=(X_train.shape[1],)),
        Dense(25, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])
    model.fit(X_train, y_train, epochs=100, batch_size=32, validation_data=(X_test, y_test), verbose=1)

    return model, scaler

# Fungsi untuk memuat model yang telah disimpan
def load_models():
    try:
        model_svm = joblib.load('svm_model.joblib')
        scaler_svm = joblib.load('svm_scaler.joblib')
    except FileNotFoundError:
        model_svm, scaler_svm = None, None

    try:
        model_nn = tf.keras.models.load_model('nn_model')
        scaler_nn = joblib.load('nn_scaler.joblib')
    except (FileNotFoundError, OSError):
        model_nn, scaler_nn = None, None

    return model_svm, scaler_svm, model_nn, scaler_nn

# Fungsi untuk menyimpan model yang telah dilatih
def save_models(model_svm, scaler_svm, model_nn, scaler_nn):
    joblib.dump(model_svm, 'svm_model.joblib')
    joblib.dump(scaler_svm, 'svm_scaler.joblib')
    model_nn.save('nn_model')
    joblib.dump(scaler_nn, 'nn_scaler.joblib')

# Fungsi untuk memprediksi arah pergerakan menggunakan gabungan SVM dan Neural Network
def predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df):
    last_data = df[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']].iloc[-1:].dropna()
    if last_data.empty:
        return None

    last_data_scaled = scaler_svm.transform(last_data)

    svm_prediction = model_svm.predict(last_data_scaled)
    nn_prediction = model_nn.predict(scaler_nn.transform(last_data))

    combined_prediction = np.mean([svm_prediction, nn_prediction])
    return 1 if combined_prediction > 0.5 else 0

def trailing_sell(last_price, highest_price, entry_price, initial_sell_lo):
    max_pl = (highest_price - entry_price) / entry_price * 100
    new_trailing_percent = calculate_new_sell_lo(initial_sell_lo, max_pl)
    sell_trigger_price = highest_price * (1 - new_trailing_percent / 100)

    if last_price < sell_trigger_price:
        logging.info(f"Trailing sell triggered at {last_price:.4f} USDT dengan New Sell-lo%: {new_trailing_percent:.2f}%")
        return True
    return False

def execute_order(order_type, price, amount):
    try:
        logging.info(f"Mencoba untuk melakukan {order_type} order pada harga {price} untuk jumlah {amount}")
        order = exchange.create_order(PAIR_SYMBOL, 'limit', order_type, amount, price)
        logging.info(f"{order_type.capitalize()} order berhasil: {order}")
    except Exception as e:
        logging.error(f"Kesalahan saat mencoba {order_type} order: {e}")

def main():
    global total_profit
    if not check_usdt_balance():
        return

    model_svm, scaler_svm, model_nn, scaler_nn = load_models()
    if not model_svm or not model_nn:
        logging.info("Melatih model karena belum tersedia...")
        df = fetch_data()
        df = calculate_indicators(df)
        model_svm, scaler_svm = train_svm_model(df)
        model_nn, scaler_nn = train_nn_model(df)
        save_models(model_svm, scaler_svm, model_nn, scaler_nn)
    else:
        logging.info("Model yang tersimpan telah dimuat.")

    while True:
        df = fetch_data()
        df = calculate_indicators(df)

        prediction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df)

        if prediction == 1:
            # Buat order beli pada harga terakhir
            last_price = df['close'].iloc[-1]
            execute_order('buy', last_price, amount_per_trade)
        elif prediction == 0:
            # Mengatur trailing sell jika sudah membeli sebelumnya
            # Logika trailing sell akan diimplementasikan di sini jika diperlukan

            # Cek apakah ada posisi terbuka dan lakukan trailing sell jika kondisi terpenuhi
            if ENABLE_TRAILING_SELL_ADVANCED:
                # Ambil data harga tertinggi
                highest_price = df['high'].max()
                entry_price = df['close'].iloc[-1]  # Anggap harga terakhir sebagai harga entry
                if trailing_sell(last_price, highest_price, entry_price, INITIAL_SELL_LO):
                    execute_order('sell', last_price, amount_per_trade)

        time.sleep(60)  # Tunggu selama 60 detik sebelum iterasi berikutnya

if __name__ == "__main__":
    main()
