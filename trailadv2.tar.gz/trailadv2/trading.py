import pandas as pd
import time
import logging
from config import exchange, symbol, interval, amount_per_trade, grid_levels, grid_size, trailing_sell_percent
from ml_model import train_svm_model, train_nn_model, predict_direction_combined, calculate_indicators

logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0

def check_usdt_balance():
    balance = exchange.fetch_balance()
    usdt_balance = balance.get('total', {}).get('USDT', 0)
    if usdt_balance < amount_per_trade * grid_levels:
        logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
        return False
    else:
        logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
        return True

def fetch_data():
    try:
        logging.info("Mengambil data dari API...")
        ohlcv = exchange.fetch_ohlcv(symbol, interval)
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        logging.info("Data berhasil diambil.")
        return df
    except Exception as e:
        logging.error(f"Error saat mengambil data: {e}")
        return None

def trailing_sell(last_price, highest_price):
    sell_trigger_price = highest_price * (1 - trailing_sell_percent)
    if last_price < sell_trigger_price:
        logging.info(f"Trailing sell triggered at {last_price:.4f} USDT.")
        return True
    return False

def main():
    global total_profit
    if not check_usdt_balance():
        return

    df = fetch_data()
    if df is None:
        logging.error("Tidak ada data yang tersedia untuk melanjutkan bot.")
        return

    df['RSI'] = calculate_rsi(df)
    df = calculate_indicators(df)
    model_svm, scaler_svm = train_svm_model(df)
    model_nn, scaler_nn = train_nn_model(df)

    logging.info("Memulai trading untuk pasangan %s", symbol)
    entry_price = None
    highest_price = 0

    while True:
        try:
            df = fetch_data()
            if df is None:
                logging.error("Tidak dapat melanjutkan, gagal mengambil data.")
                time.sleep(60)
                continue

            df['RSI'] = calculate_rsi(df)
            df = calculate_indicators(df)
            last_price = df['close'].iloc[-1]
            direction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df)

            if direction is not None:
                if direction == 1:
                    logging.info(f"Membeli pada harga {last_price:.4f} USDT.")
                    entry_price = last_price
                    highest_price = last_price
                elif trailing_sell(last_price, highest_price):
                    logging.info("Menjual aset berdasarkan trailing sell.")
                    break

            time.sleep(300)  # jeda 5 menit

        except Exception as e:
            logging.error(f"Error dalam loop utama: {e}")
            time.sleep(60)
