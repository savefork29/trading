from config import USER_DATA, AXM_PRICE_API_URL
import requests

def start_buy_axm(update, context):
    user_id = update.effective_user.id
    user_data = USER_DATA.get(user_id, {"idr": 0})

    if user_data["idr"] <= 0:
        update.message.reply_text("Saldo anda adalah Rp 0. Silahkan deposit terlebih dahulu.")
        return

    update.message.reply_text(
        f"Anda memiliki saldo sebesar Rp {user_data['idr']:,}. Silahkan masukkan nominal yang ingin Anda belanjakan ..."
    )

def handle_buy_axm(update, context):
    user_id = update.effective_user.id
    amount_idr = int(update.message.text)

    # Cek saldo
    if USER_DATA[user_id]["idr"] < amount_idr:
        update.message.reply_text("Saldo tidak mencukupi. Silahkan masukkan nominal yang sesuai.")
        return

    # Hitung jumlah AXM berdasarkan harga real-time
    response = requests.get(AXM_PRICE_API_URL)
    axm_price_idr = response.json()["axiome"]["idr"]
    amount_axm = amount_idr / axm_price_idr

    # Perbarui saldo pengguna
    USER_DATA[user_id]["idr"] -= amount_idr
    USER_DATA[user_id]["axm"] += amount_axm

    update.message.reply_text(
        f"Transaksi berhasil! Kamu membeli {amount_axm:.2f} AXM. Sisa saldo Rp {USER_DATA[user_id]['idr']:,}."
    )
