from telegram import ReplyKeyboardMarkup
from config import USER_DATA

def get_balance(update, context):
    user_id = update.effective_user.id

    # Ambil saldo pengguna (default: Rp 0, 0 AXM)
    user_data = USER_DATA.get(user_id, {"idr": 0, "axm": 0})
    balance_idr = user_data["idr"]
    balance_axm = user_data["axm"]

    # Buat keyboard untuk opsi
    reply_keyboard = [["🛒 Beli AXM", "Batalkan"]]
    reply_markup = ReplyKeyboardMarkup(reply_keyboard, resize_keyboard=True)

    # Kirim pesan ke pengguna
    update.message.reply_text(
        f"ℹ Kamu memiliki saldo sebesar Rp {balance_idr:,} dan {balance_axm:.2f} AXM.",
        reply_markup=reply_markup
    )
