from telegram import InlineKeyboardMarkup, InlineKeyboardButton
from config import USER_DATA, USDT_ADDRESS, PAYPAL_ADDRESS, ADMIN_TELEGRAM_ID

def start_deposit(update, context):
    inline_keyboard = [
        [InlineKeyboardButton("Via USDT", callback_data="deposit_usdt")],
        [InlineKeyboardButton("Via PayPal", callback_data="deposit_paypal")]
    ]
    reply_markup = InlineKeyboardMarkup(inline_keyboard)

    update.message.reply_text("Silahkan pilih metode pembayaran di bawah ini:", reply_markup=reply_markup)

def process_deposit_method(update, context):
    query = update.callback_query
    user_id = update.effective_user.id

    if query.data == "deposit_usdt":
        query.edit_message_text("Silahkan masukkan nominal USD yang akan didepositkan ...")
        context.user_data["method"] = "USDT"
    elif query.data == "deposit_paypal":
        query.edit_message_text("Silahkan masukkan nominal USD yang akan didepositkan ...")
        context.user_data["method"] = "PayPal"

def handle_deposit_amount(update, context):
    user_id = update.effective_user.id
    amount_usd = float(update.message.text)

    # Simpan data deposit
    context.user_data["amount"] = amount_usd
    payment_method = context.user_data["method"]
    fee = amount_usd * 0.012
    total_with_fee = amount_usd + fee

    # Kirim pesan ke admin untuk konfirmasi
    context.bot.send_message(
        chat_id=ADMIN_TELEGRAM_ID,
        text=(
            f"Konfirmasi Deposit:\n"
            f"User: {user_id}\n"
            f"Metode: {payment_method}\n"
            f"Jumlah: {amount_usd:.2f} USD\n"
            f"Fee: {fee:.2f} USD\n"
            f"Total: {total_with_fee:.2f} USD\n\n"
            f"/confirm {user_id} untuk konfirmasi\n"
            f"/reject {user_id} untuk menolak"
        )
    )
    update.message.reply_text("Transaksi Anda akan segera diproses, tunggu konfirmasi dari Admin.")
