from config import USER_DATA

def start_withdraw(update, context):
    update.message.reply_text("Silahkan masukkan nominal AXM yang akan ditarik ...")

def handle_withdraw_amount(update, context):
    user_id = update.effective_user.id
    amount_axm = float(update.message.text)

    # Cek saldo
    if USER_DATA[user_id]["axm"] < amount_axm:
        update.message.reply_text("Saldo AXM tidak mencukupi. Silahkan masukkan nominal yang sesuai.")
        return

    update.message.reply_text("Masukkan alamat AXM Anda ...")
    context.user_data["withdraw_amount"] = amount_axm

def handle_withdraw_address(update, context):
    user_id = update.effective_user.id
    wallet_address = update.message.text
    amount_axm = context.user_data["withdraw_amount"]

    # Kirim pesan ke admin
    context.bot.send_message(
        chat_id=ADMIN_TELEGRAM_ID,
        text=(
            f"Permintaan Withdraw:\n"
            f"User: {user_id}\n"
            f"Jumlah: {amount_axm:.2f} AXM\n"
            f"Alamat: {wallet_address}\n\n"
            f"/confirmwd {user_id} untuk konfirmasi\n"
            f"/rejectwd {user_id} untuk menolak"
        )
    )
    update.message.reply_text("Permintaan withdraw Anda telah dikirim. Tunggu konfirmasi dari Admin.")
