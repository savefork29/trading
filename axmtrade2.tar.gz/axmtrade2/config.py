import os
from dotenv import load_dotenv

# Memuat variabel lingkungan dari file .env jika ada
load_dotenv()

# Token bot Telegram
BOT_TOKEN = os.getenv("BOT_TOKEN")

# Admin Telegram ID
ADMIN_TELEGRAM_ID = os.getenv("ADMIN_TELEGRAM_ID")

# Alamat wallet USDT BEP20
USDT_BEP20_ADDRESS = os.getenv("USDT_BEP20_ADDRESS", "0xYourUSDTBEP20WalletAddress")

# Alamat PayPal
PAYPAL_ADDRESS = os.getenv("PAYPAL_ADDRESS", "your-paypal-email@example.com")

# API Harga AXM (gunakan CoinGecko atau platform lain yang mendukung)
AXM_PRICE_API_URL = "https://api.coingecko.com/api/v3/simple/price?ids=axiome&vs_currencies=usd"

# Komisi transaksi (%)
TRANSACTION_FEE_PERCENTAGE = 1.0  # 1%
