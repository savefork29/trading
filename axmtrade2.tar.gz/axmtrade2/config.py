import os
from dotenv import load_dotenv

# Muat variabel lingkungan dari file .env
load_dotenv()

# Token bot Telegram
BOT_TOKEN = os.getenv("BOT_TOKEN")

# ID admin Telegram
ADMIN_TELEGRAM_ID = int(os.getenv("ADMIN_TELEGRAM_ID"))

# Alamat pembayaran
USDT_ADDRESS = os.getenv("USDT_ADDRESS")  # Alamat wallet USDT BEP20
PAYPAL_ADDRESS = os.getenv("PAYPAL_ADDRESS")  # Alamat PayPal

# Komisi transaksi
TRANSACTION_FEE_PERCENTAGE = float(os.getenv("TRANSACTION_FEE_PERCENTAGE", 1.2))  # Default 1.2%

# API harga AXM
AXM_PRICE_API_URL = "https://api.coingecko.com/api/v3/simple/price?ids=axiome&vs_currencies=idr"

# Simpan data pengguna (gunakan database untuk produksi; ini hanya untuk simulasi)
USER_DATA = {}
