import logging
import requests
from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Updater, CommandHandler, CallbackContext, MessageHandler, Filters, CallbackQueryHandler
from config import BOT_TOKEN, ADMIN_TELEGRAM_ID, AXM_PRICE_API_URL, USDT_BEP20_ADDRESS, PAYPAL_ADDRESS

# Logging konfigurasi
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Penyimpanan saldo dan transaksi
user_balances = {}  # Contoh: {user_id: {"idr_balance": 0, "axm_balance": 0}}
pending_transactions = {}

# Fungsi untuk mendapatkan harga AXM
def get_axm_price():
    try:
        response = requests.get(AXM_PRICE_API_URL)
        response.raise_for_status()
        data = response.json()
        return data["axiome"]["usd"]
    except Exception as e:
        logging.error(f"Gagal mendapatkan harga AXM: {e}")
        return 0.0

# Fungsi untuk memulai bot
def start(update: Update, context: CallbackContext):
    reply_keyboard = [
        ["💰 Saldo", "📤 Deposit"],
        ["📥 Withdraw", "🛒 Beli AXM"]
    ]
    reply_markup = ReplyKeyboardMarkup(reply_keyboard, resize_keyboard=True)

    update.message.reply_text(
        "Selamat datang di bot jual/beli AXM! Pilih menu di bawah ini untuk melanjutkan.",
        reply_markup=reply_markup
    )

# 💰 Saldo
def check_balance(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    balance = user_balances.get(user_id, {"idr_balance": 0, "axm_balance": 0})

    reply_keyboard = [["🛒 Beli AXM", "Batalkan"]]
    reply_markup = ReplyKeyboardMarkup(reply_keyboard, resize_keyboard=True)

    update.message.reply_text(
        f"ℹ Kamu memiliki saldo sebesar Rp {balance['idr_balance']} dan {balance['axm_balance']} AXM.",
        reply_markup=reply_markup
    )

# 📤 Deposit
def deposit(update: Update, context: CallbackContext):
    reply_markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("Via USDT", callback_data='deposit_usdt')],
        [InlineKeyboardButton("PayPal", callback_data='deposit_paypal')]
    ])
    update.message.reply_text("Silahkan pilih metode pembayaran di bawah ini:", reply_markup=reply_markup)

def handle_deposit_callback(update: Update, context: CallbackContext):
    query = update.callback_query
    query.answer()
    user_id = update.effective_user.id

    if query.data == 'deposit_usdt':
        query.edit_message_text("Silahkan masukkan nominal USD yang akan didepositkan:")
        context.user_data['method'] = 'usdt'
    elif query.data == 'deposit_paypal':
        query.edit_message_text("Silahkan masukkan nominal USD yang akan didepositkan:")
        context.user_data['method'] = 'paypal'

def confirm_deposit(update: Update, context: CallbackContext):
    try:
        transaction_id = int(context.args[0])
        transaction = pending_transactions.get(transaction_id)

        if not transaction or transaction["status"] != "waiting":
            update.message.reply_text("Transaksi tidak ditemukan atau sudah diproses.")
            return

        user_id = transaction["user_id"]
        nominal = transaction["amount"]
        fee = transaction["fee"]

        # Perbarui saldo pengguna
        if user_id not in user_balances:
            user_balances[user_id] = {"idr_balance": 0, "axm_balance": 0}

        user_balances[user_id]["idr_balance"] += nominal

        # Tandai transaksi sebagai selesai
        transaction["status"] = "confirmed"

        # Kirim notifikasi ke pengguna
        context.bot.send_message(
            chat_id=user_id,
            text=f"Deposit sebesar Rp {nominal:.2f} telah berhasil dikonfirmasi. Saldo Anda telah diperbarui."
        )

        update.message.reply_text(f"Transaksi ID {transaction_id} telah dikonfirmasi dan saldo pengguna diperbarui.")
    except (IndexError, ValueError):
        update.message.reply_text("Gunakan format: /confirm <id>")

def process_deposit(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    nominal = float(update.message.text)
    method = context.user_data.get('method')
    transaction_id = len(pending_transactions) + 1
    fee = nominal * 0.012  # Contoh fee 1.2%
    unique_code = int(str(user_id)[-3:])  # 3 digit unik

    total_payment = nominal + fee + (unique_code / 1000)  # Nominal dengan tambahan kode unik

    pending_transactions[transaction_id] = {
        "user_id": user_id,
        "amount": nominal,
        "fee": fee,
        "unique_code": unique_code,
        "method": method,
        "status": "waiting"
    }

    if method == 'usdt':
        payment_info = f"Kirim {total_payment:.3f} USDT ke alamat berikut (BEP20):\n\n{USDT_BEP20_ADDRESS}\n\n"
    elif method == 'paypal':
        payment_info = f"Kirim {total_payment:.3f} USD ke alamat PayPal berikut:\n\n{PAYPAL_ADDRESS}\n\n"

    context.bot.send_message(
        chat_id=ADMIN_TELEGRAM_ID,
        text=f"Konfirmasi Deposit:\nID Transaksi: {transaction_id}\nUser: {user_id}\nJumlah: {nominal:.2f} USD\nMetode: {method}\n\n/confirm {transaction_id} untuk konfirmasi\n/reject {transaction_id} untuk menolak"
    )

    update.message.reply_text(
        f"Permintaan Deposit Anda telah dikonfirmasi. {payment_info}"
        f"Pastikan Anda mengirim jumlah dengan kode unik {unique_code} untuk mempermudah identifikasi."
    )

# 🛒 Beli AXM
def buy_axm(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    balance = user_balances.get(user_id, {"idr_balance": 0, "axm_balance": 0})

    if balance['idr_balance'] <= 0:
        update.message.reply_text("Saldo anda adalah Rp 0. Silahkan deposit terlebih dahulu.", reply_markup=ReplyKeyboardMarkup([["Batalkan"]], resize_keyboard=True))
        return

    update.message.reply_text("Silahkan masukkan nominal dalam Rp yang ingin dibelanjakan:")
    context.user_data['menu'] = 'buy_axm'

def process_buy_axm(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    nominal = float(update.message.text)
    axm_price = get_axm_price() * 15000  # Konversi ke IDR
    axm_amount = nominal / axm_price
    fee = axm_amount * 0.01  # Contoh fee 1%
    total_axm = axm_amount - fee

    balance = user_balances.get(user_id, {"idr_balance": 0, "axm_balance": 0})
    if balance['idr_balance'] < nominal:
        update.message.reply_text("Saldo IDR tidak mencukupi.")
        return

    balance['idr_balance'] -= nominal
    balance['axm_balance'] += total_axm
    user_balances[user_id] = balance

    update.message.reply_text(f"Pembelian berhasil! Anda menerima {total_axm:.2f} AXM.")

# 📥 Withdraw
def withdraw(update: Update, context: CallbackContext):
    update.message.reply_text("Silahkan masukkan nominal AXM yang akan ditarik:")
    context.user_data['menu'] = 'withdraw'

def process_withdraw(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    nominal = float(update.message.text)
    update.message.reply_text("Masukkan alamat AXM Anda:")
    context.user_data['withdraw_amount'] = nominal

def finalize_withdraw(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    wallet_address = update.message.text
    nominal = context.user_data.get('withdraw_amount')

    context.bot.send_message(
        chat_id=ADMIN_TELEGRAM_ID,
        text=f"Konfirmasi Withdraw:\nUser: {user_id}\nJumlah: {nominal} AXM\nAlamat: {wallet_address}\n\n/confirmwd {user_id} untuk konfirmasi\n/rejectwd {user_id} untuk menolak"
    )
    update.message.reply_text("Permintaan Anda telah diteruskan ke admin.")

# Fungsi utama untuk menjalankan bot
def main():
    updater = Updater(BOT_TOKEN)
    dispatcher = updater.dispatcher

    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(CommandHandler("buy", buy_axm))
    dispatcher.add_handler(CommandHandler("deposit", deposit))
    dispatcher.add_handler(CallbackQueryHandler(handle_deposit_callback))
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, process_buy_axm))

    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
