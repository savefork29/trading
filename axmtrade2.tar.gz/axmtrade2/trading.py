import logging
from telegram.ext import Updater, CommandHandler, MessageHandler, CallbackQueryHandler, Filters
from commands.balance import get_balance
from commands.deposit import start_deposit, process_deposit_method, handle_deposit_amount
from commands.withdraw import start_withdraw, handle_withdraw_amount, handle_withdraw_address
from commands.buy_axm import start_buy_axm, handle_buy_axm
from config import BOT_TOKEN, ADMIN_TELEGRAM_ID, USDT_ADDRESS, PAYPAL_ADDRESS, TRANSACTION_FEE_PERCENTAGE

# Logging konfigurasi
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Fungsi utama untuk memulai bot
def start(update, context):
    reply_keyboard = [
        [" Saldo", " Deposit"],
        [" Withdraw", " Beli AXM"]
    ]
    update.message.reply_text(
        "Selamat datang di bot jual/beli AXM! Pilih menu di bawah ini untuk melanjutkan.",
        reply_markup=ReplyKeyboardMarkup(reply_keyboard, resize_keyboard=True)
    )

# Menangani teks dari pengguna
def handle_text(update, context):
    text = update.message.text

    if text == " Saldo":
        get_balance(update, context)
    elif text == " Deposit":
        start_deposit(update, context)
    elif text == " Withdraw":
        start_withdraw(update, context)
    elif text == " Beli AXM":
        start_buy_axm(update, context)
    else:
        update.message.reply_text("Perintah tidak dikenal. Silahkan pilih menu yang tersedia.")

# Callback untuk deposit (USDT atau PayPal)
def handle_deposit_callback(update, context):
    query = update.callback_query
    method = query.data

    if method == "deposit_usdt":
        context.user_data["payment_method"] = "USDT"
        query.edit_message_text(
            f"Silahkan masukkan nominal USD yang akan didepositkan. Pembayaran akan dilakukan ke:\n\n"
            f"Alamat USDT BEP20: {USDT_ADDRESS}\n"
            f"(Fee: {TRANSACTION_FEE_PERCENTAGE:.2f}%)"
        )
    elif method == "deposit_paypal":
        context.user_data["payment_method"] = "PayPal"
        query.edit_message_text(
            f"Silahkan masukkan nominal USD yang akan didepositkan. Pembayaran akan dilakukan ke:\n\n"
            f"Alamat PayPal: {PAYPAL_ADDRESS}\n"
            f"(Fee: {TRANSACTION_FEE_PERCENTAGE:.2f}%)"
        )

# Fungsi utama untuk menjalankan bot
def main():
    # Inisialisasi bot
    updater = Updater(BOT_TOKEN)
    dispatcher = updater.dispatcher

    # Command handlers
    dispatcher.add_handler(CommandHandler("start", start))

    # Reply keyboard handler
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_text))

    # Callback untuk pilihan deposit
    dispatcher.add_handler(CallbackQueryHandler(handle_deposit_callback, pattern="^deposit_(usdt|paypal)$"))

    # Input dari pengguna untuk deposit (nominal)
    dispatcher.add_handler(MessageHandler(Filters.text & Filters.reply, handle_deposit_amount))

    # Input dari pengguna untuk withdraw
    dispatcher.add_handler(MessageHandler(Filters.text & Filters.reply, handle_withdraw_amount))
    dispatcher.add_handler(MessageHandler(Filters.text & Filters.reply, handle_withdraw_address))

    # Input dari pengguna untuk beli AXM
    dispatcher.add_handler(MessageHandler(Filters.text & Filters.reply, handle_buy_axm))

    # Mulai bot
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
