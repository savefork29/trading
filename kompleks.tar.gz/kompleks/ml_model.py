import os
import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.optimizers import Adam
import pickle

MODEL_SAVE_PATH = "lstm_model.h5"
SCALER_SAVE_PATH = "lstm_scaler.pkl"

# Fungsi untuk menghitung indikator tambahan
def calculate_indicators(data):
    data['ATR'] = data['close'].rolling(window=14).apply(lambda x: x.max() - x.min())
    data['MA20'] = data['close'].rolling(window=20).mean()
    data['UpperBand'] = data['MA20'] + 2 * data['close'].rolling(window=20).std()
    data['LowerBand'] = data['MA20'] - 2 * data['close'].rolling(window=20).std()
    data['ADX'] = data['close'].rolling(window=14).apply(lambda x: (x.diff().abs().sum() / 14) * 100)
    return data

# Fungsi untuk membuat data time-series dalam bentuk jendela waktu
def create_time_series_data(data, features, target, time_steps=10):
    X, y = [], []
    for i in range(len(data) - time_steps):
        X.append(data[features].iloc[i:i+time_steps].values)
        y.append(data[target].iloc[i+time_steps])
    return np.array(X), np.array(y)

# Fungsi untuk melatih model SVM
def train_svm_model(data):
    data = calculate_indicators(data)
    data['PriceChange'] = data['close'].diff().shift(-1)
    data['PriceDirection'] = (data['PriceChange'] > 0).astype(int)
    data.dropna(inplace=True)

    # Fitur dan label untuk SVM
    X = data[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']]
    y = data['PriceDirection']

    scaler_svm = StandardScaler()
    X_scaled = scaler_svm.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # Buat dan latih model SVM
    model_svm = SVC(kernel='linear')
    model_svm.fit(X_train, y_train)

    return model_svm, scaler_svm

# Fungsi untuk melatih model LSTM
def train_lstm_model(data):
    data = calculate_indicators(data)
    data['target'] = (data['close'].shift(-1) > data['close']).astype(int)
    data.dropna(inplace=True)

    features = ['open', 'high', 'low', 'close', 'volume', 'RSI', 'ATR', 'ADX']
    target = 'target'
    time_steps = 10

    scaler_lstm = StandardScaler()
    data[features] = scaler_lstm.fit_transform(data[features])

    X, y = create_time_series_data(data, features, target, time_steps)

    # Split data
    split = int(len(X) * 0.8)
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]

    # Bangun model LSTM
    model_lstm = Sequential([
        LSTM(64, activation='tanh', return_sequences=True, input_shape=(time_steps, len(features))),
        Dropout(0.2),
        LSTM(32, activation='tanh', return_sequences=False),
        Dropout(0.2),
        Dense(1, activation='sigmoid')
    ])

    model_lstm.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])
    model_lstm.fit(X_train, y_train, epochs=30, batch_size=16, verbose=1)

    # Simpan model dan scaler
    model_lstm.save(MODEL_SAVE_PATH)
    with open(SCALER_SAVE_PATH, 'wb') as f:
        pickle.dump(scaler_lstm, f)

    return model_lstm, scaler_lstm

# Fungsi untuk memuat model LSTM yang sudah dilatih
def load_lstm_model():
    if os.path.exists(MODEL_SAVE_PATH) and os.path.exists(SCALER_SAVE_PATH):
        model_lstm = load_model(MODEL_SAVE_PATH)
        with open(SCALER_SAVE_PATH, 'rb') as f:
            scaler_lstm = pickle.load(f)
        return model_lstm, scaler_lstm
    else:
        raise FileNotFoundError("Model atau scaler tidak ditemukan. Silakan latih model terlebih dahulu.")

# Fungsi untuk memprediksi arah harga menggunakan LSTM
def predict_direction_lstm(model_lstm, scaler_lstm, df, time_steps=10):
    df = calculate_indicators(df)
    features = ['open', 'high', 'low', 'close', 'volume', 'RSI', 'ATR', 'ADX']
    df[features] = scaler_lstm.transform(df[features])

    if len(df) < time_steps:
        raise ValueError("Data tidak cukup untuk membuat jendela waktu.")

    X = np.expand_dims(df[features].iloc[-time_steps:].values, axis=0)
    prediction = model_lstm.predict(X)
    return 1 if prediction >= 0.5 else 0
