import pandas as pd
import time
import logging
from config import (
    exchange, PAIR_SYMBOL, interval, amount_per_trade, grid_levels, grid_size,
    trailing_sell_percent, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED,
    INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT, ENABLE_ENTRY_EXIT_ADJUSTMENT,
    ENTRY_BUFFER_PERCENT, EXIT_BUFFER_PERCENT, ENABLE_DYNAMIC_TRAILING_SELL,
    TRAILING_SELL_BASE_PERCENT, TRAILING_SELL_DYNAMIC_ADJUSTMENT
)
from ml_model import train_nn_model, load_trained_models, predict_direction_nn, calculate_indicators

# Inisialisasi logging dengan level informasi
logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0

def check_usdt_balance():
    # (Tetap sama seperti kode sebelumnya)
    try:
        balance = exchange.fetch_balance()
        usdt_balance = balance.get('total', {}).get('USDT', 0)
        if usdt_balance < amount_per_trade * grid_levels:
            logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
            return False
        else:
            logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
            return True
    except Exception as e:
        logging.error(f"Error checking USDT balance: {e}")
        return False

def fetch_data():
    # (Tetap sama seperti kode sebelumnya)
    try:
        ohlcv = exchange.fetch_ohlcv(PAIR_SYMBOL, interval)
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df = calculate_indicators(df)  # Kalkulasi indikator tambahan
        return df
    except Exception as e:
        logging.error(f"Error fetching data: {e}")
        return pd.DataFrame()

def calculate_rsi(df, period=14):
    # (Tetap sama seperti kode sebelumnya)
    try:
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    except Exception as e:
        logging.error(f"Error calculating RSI: {e}")
        return pd.Series([])

def place_grid_orders(df):
    # (Tetap sama seperti kode sebelumnya)
    try:
        last_price = df['close'].iloc[-1]
        grid_prices = [last_price * (1 + grid_size * i) for i in range(-grid_levels, grid_levels + 1)]
        for price in grid_prices:
            logging.info(f"Grid order ditempatkan pada harga: {price:.4f} USDT")
    except Exception as e:
        logging.error(f"Error placing grid orders: {e}")

def trailing_sell(last_price, highest_price, entry_price):
    try:
        # Menggunakan trailing sell dinamis jika diaktifkan
        if ENABLE_DYNAMIC_TRAILING_SELL:
            dynamic_trailing_percent = TRAILING_SELL_BASE_PERCENT + TRAILING_SELL_DYNAMIC_ADJUSTMENT
            sell_trigger_price = highest_price * (1 - dynamic_trailing_percent)
        else:
            sell_trigger_price = highest_price * (1 - trailing_sell_percent)

        if last_price < sell_trigger_price:
            logging.info(f"Trailing sell triggered at {last_price:.4f} USDT. Selling...")
            try:
                exchange.create_market_sell_order(PAIR_SYMBOL, amount_per_trade)
                logging.info(f"Sell order executed at price: {last_price:.4f} USDT.")
                return True
            except Exception as e:
                logging.error(f"Error executing sell order: {e}")
                return False
        return False
    except Exception as e:
        logging.error(f"Error in trailing sell logic: {e}")
        return False

def main():
    try:
        model_nn, scaler_nn = load_trained_models()
        if model_nn is None:
            logging.info("Model tidak ditemukan. Melatih model baru...")
            data = fetch_data()
            model_nn, scaler_nn = train_nn_model(data)
            logging.info("Pelatihan model Neural Network selesai.")
        else:
            logging.info("Model Neural Network yang ada telah dimuat.")

        if not check_usdt_balance():
            return

        highest_price = 0
        entry_price = 0

        while True:
            df = fetch_data()
            if df.empty:
                logging.error("Tidak ada data yang diperoleh. Mencoba kembali...")
                time.sleep(60)
                continue

            last_price = df['close'].iloc[-1]
            rsi = calculate_rsi(df)
            highest_price = max(highest_price, last_price)
            prediction = predict_direction_nn(model_nn, scaler_nn, df)

            if prediction is not None:
                if prediction == 1 and entry_price == 0:
                    if ENABLE_ENTRY_EXIT_ADJUSTMENT:
                        # Menyesuaikan harga entry jika fitur ini diaktifkan
                        adjusted_entry_price = last_price * (1 + ENTRY_BUFFER_PERCENT)
                        if last_price >= adjusted_entry_price:
                            logging.info(f"Sinyal beli terdeteksi pada harga: {last_price:.4f} USDT. Menempatkan pesanan beli...")
                            try:
                                total_order_value = last_price * amount_per_trade
                                if total_order_value >= 5:
                                    exchange.options['createMarketBuyOrderRequiresPrice'] = False
                                    exchange.create_market_buy_order(PAIR_SYMBOL, amount=amount_per_trade)
                                    entry_price = last_price
                                    logging.info(f"Pesanan beli dieksekusi pada harga: {last_price:.4f} USDT.")
                                else:
                                    logging.warning(f"Nilai total order kurang dari 5 USDT: {total_order_value:.4f} USDT.")
                            except Exception as e:
                                logging.error(f"Error executing buy order: {e}")

                elif prediction == 0 and entry_price > 0:
                    if trailing_sell(last_price, highest_price, entry_price):
                        entry_price = 0

            # Output log evaluasi performa model secara berkala
            if time.time() % 3600 == 0:  # Setiap jam
                logging.info("Evaluating model performance and recalculating indicators...")

            time.sleep(60)

    except Exception as e:
        logging.error(f"Error tak terduga dalam main loop: {e}")

if __name__ == "__main__":
    main()
