import os
import ccxt

# API Key dan Secret Key Tokocrypto
API_KEY = os.getenv('TOKOCRYPTO_API_KEY')
SECRET_KEY = os.getenv('TOKOCRYPTO_SECRET_KEY')

# Konfigurasi trading
PAIR_SYMBOL = 'BNB/USDT'
symbol = PAIR_SYMBOL  # Alias untuk konsistensi
interval = '5m'
amount_per_trade = 0.001
grid_levels = 5
grid_size = 0.01
trailing_sell_percent = 0.015

# Target profit dan trailing sell canggih
TARGET_PROFIT = 10
ENABLE_TRAILING_SELL_ADVANCED = True
INITIAL_SELL_LO = -40
TRAILING_SELL_ADJUSTMENT = 0.2

# Penyesuaian Entry-Exit
ENABLE_ENTRY_EXIT_ADJUSTMENT = True  # Untuk mengaktifkan strategi entry-exit tambahan
ENTRY_BUFFER_PERCENT = 0.01  # Persentase buffer untuk entry di atas close liquidity
EXIT_BUFFER_PERCENT = 0.02  # Persentase buffer untuk exit saat close liquidity

# Konfigurasi Trailing Sell Dinamis
ENABLE_DYNAMIC_TRAILING_SELL = True  # Untuk mengaktifkan trailing sell dinamis
TRAILING_SELL_BASE_PERCENT = 0.01  # Persentase trailing sell dasar
TRAILING_SELL_DYNAMIC_ADJUSTMENT = 0.005  # Penyesuaian dinamis untuk trailing sell

# Inisialisasi exchange Tokocrypto
exchange = ccxt.tokocrypto({
    'apiKey': API_KEY,
    'secret': SECRET_KEY,
})
