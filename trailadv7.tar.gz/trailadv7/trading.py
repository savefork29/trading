import pandas as pd
import time
import logging
from config import (
    exchange, PAIR_SYMBOL, interval, amount_per_trade, grid_levels, grid_size,
    trailing_sell_percent, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED,
    INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT
)
from ml_model import train_svm_model, train_nn_model, load_trained_models, predict_direction_combined, calculate_indicators

logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0

def check_usdt_balance():
    balance = exchange.fetch_balance()
    usdt_balance = balance.get('total', {}).get('USDT', 0)
    if usdt_balance < amount_per_trade * grid_levels:
        logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
        return False
    else:
        logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
        return True

def fetch_data():
    ohlcv = exchange.fetch_ohlcv(PAIR_SYMBOL, interval)
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df

def calculate_rsi(df, period=14):
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def place_grid_orders(df):
    last_price = df['close'].iloc[-1]
    grid_prices = [last_price * (1 + grid_size * i) for i in range(-grid_levels, grid_levels + 1)]
    for price in grid_prices:
        logging.info(f"Grid order ditempatkan pada harga: {price:.4f} USDT")

def trailing_sell(last_price, highest_price, entry_price):
    if ENABLE_TRAILING_SELL_ADVANCED:
        adjusted_trailing_percent = trailing_sell_percent + TRAILING_SELL_ADJUSTMENT
        sell_trigger_price = highest_price * (1 - adjusted_trailing_percent)
    else:
        sell_trigger_price = highest_price * (1 - trailing_sell_percent)

        if last_price < sell_trigger_price:
        logging.info(f"Trailing sell triggered at {last_price:.4f} USDT. Selling...")
        # Logika untuk mengeksekusi pesanan jual
        try:
            # Eksekusi pesanan jual
            exchange.create_market_sell_order(PAIR_SYMBOL, amount_per_trade)
            logging.info(f"Sell order executed at price: {last_price:.4f} USDT.")
            return True  # Menunjukkan bahwa pesanan jual telah dipicu
        except Exception as e:
            logging.error(f"Error executing sell order: {e}")
            return False  # Tidak ada pesanan jual yang dipicu
    return False  # Tidak ada pesanan jual yang dipicu

def main():
    # Load trained models or train new ones if not available
    model_svm, scaler_svm, model_nn, scaler_nn = load_trained_models()
    if model_svm is None or model_nn is None:
        logging.info("Model not found. Training new models...")
        data = fetch_data()
        model_svm, scaler_svm = train_svm_model(data)
        model_nn, scaler_nn = train_nn_model(data)
    else:
        logging.info("Loaded existing models.")

    # Check USDT balance
    if not check_usdt_balance():
        return

    highest_price = 0
    entry_price = 0

    while True:
        df = fetch_data()
        last_price = df['close'].iloc[-1]
        rsi = calculate_rsi(df)

        # Update highest price for trailing sell logic
        highest_price = max(highest_price, last_price)

        # Predict price direction
        combined_prediction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df)

        if combined_prediction is not None:
            if combined_prediction == 1 and entry_price == 0:  # Buy signal and no current position
                logging.info(f"Buy signal detected at price: {last_price:.4f} USDT. Placing buy order...")
                # Place buy order logic here
                try:
                    # Eksekusi pesanan beli
                    exchange.create_market_buy_order(PAIR_SYMBOL, amount_per_trade)
                    entry_price = last_price  # Update entry price setelah berhasil beli
                    logging.info(f"Buy order executed at price: {last_price:.4f} USDT.")
                except Exception as e:
                    logging.error(f"Error executing buy order: {e}")

            elif combined_prediction == 0 and entry_price > 0:  # Sell signal and current position exists
                if trailing_sell(last_price, highest_price, entry_price):
                    # Reset entry price after selling
                    entry_price = 0

        # Sleep for the duration of the interval
        time.sleep(60)  # Adjust sleep time according to your interval

if __name__ == "__main__":
    main()

