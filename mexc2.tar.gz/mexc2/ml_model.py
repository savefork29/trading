import numpy as np
import pandas as pd
import requests  # Digunakan untuk mengakses API MEXC
import pandas_ta as ta
from sklearn.preprocessing import MinMaxScaler
from keras.models import Model
from keras.layers import LSTM, Dense, Input, Activation
from keras import optimizers

# 1. Mengunduh data AXIOME/USDT dari API MEXC
url = 'https://www.mexc.com/open/api/v2/market/kline'
params = {
    'symbol': 'AXIOME_USDT',  # Menggunakan pasangan AXIOME/USDT
    'interval': '1d',  # Interval per hari
    'limit': 500,  # Batas jumlah data yang diambil
}

response = requests.get(url, params=params)
data = response.json()

# Memeriksa apakah data berhasil diambil
if response.status_code == 200:
    kline_data = data['data']
    df = pd.DataFrame(kline_data)
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    df.set_index('timestamp', inplace=True)
else:
    print(f"Error: {data['msg']}")
    exit()

# 2. Menambahkan indikator teknikal
df['RSI'] = ta.rsi(df['close'], length=15)
df['EMAF'] = ta.ema(df['close'], length=20)
df['EMAM'] = ta.ema(df['close'], length=100)
df['EMAS'] = ta.ema(df['close'], length=150)

# Membuat target untuk model
df['Target'] = df['close'] - df['open']
df['Target'] = df['Target'].shift(-1)  # Target next day's close
df['TargetClass'] = [1 if df['Target'][i] > 0 else 0 for i in range(len(df))]
df['TargetNextClose'] = df['close'].shift(-1)

# Mengisi nilai NaN dengan 0 atau rata-rata kolom
df.fillna(0, inplace=True)

# Cek bentuk data setelah mengisi NaN
print("Shape after fillna:", df.shape)

# 3. Menghapus kolom yang tidak diperlukan
df.drop(['symbol'], axis=1, inplace=True)

# 4. Skalasi data
scaler = MinMaxScaler(feature_range=(0, 1))
data_set_scaled = scaler.fit_transform(df[['open', 'high', 'low', 'close', 'volume', 'RSI', 'EMAF', 'EMAM', 'EMAS']].values)

# Cek bentuk data yang akan di-skalakan
print("Shape after scaling:", data_set_scaled.shape)

# 5. Menyiapkan input untuk LSTM
X, y = [], []
backcandles = 30  # Menggunakan 30 hari sebelumnya untuk prediksi
for i in range(backcandles, data_set_scaled.shape[0]):
    X.append(data_set_scaled[i-backcandles:i, :-1])  # Semua kolom kecuali target
    y.append(data_set_scaled[i, -1])  # Kolom target

X, y = np.array(X), np.array(y)
y = np.reshape(y, (len(y), 1))

# Cek apakah data kosong atau tidak
print("Shape of X:", X.shape)
print("Shape of y:", y.shape)

# 6. Membagi data menjadi pelatihan dan pengujian
splitlimit = int(len(X) * 0.8)  # 80% untuk pelatihan, 20% untuk pengujian
X_train, X_test = X[:splitlimit], X[splitlimit:]
y_train, y_test = y[:splitlimit], y[splitlimit:]

# 7. Membangun model LSTM
lstm_input = Input(shape=(backcandles, X.shape[2]), name='lstm_input')
inputs = LSTM(150, name='first_layer')(lstm_input)
inputs = Dense(1, name='dense_layer')(inputs)
output = Activation('linear', name='output')(inputs)
model = Model(inputs=lstm_input, outputs=output)

# 8. Kompilasi dan pelatihan model
adam = optimizers.Adam()
model.compile(optimizer=adam, loss='mse')
model.fit(x=X_train, y=y_train, batch_size=15, epochs=30, shuffle=True, validation_split=0.1)

# 9. Menyimpan model ke dalam file .h5 dengan nama 'lstm_model.h5'
model.save("lstm_model.h5")
print("Model berhasil disimpan sebagai lstm_model.h5")
