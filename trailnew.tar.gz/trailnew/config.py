# config.py

import os
import ccxt

# API Keys untuk Tokocrypto
API_KEY = os.getenv('TOKOCRYPTO_API_KEY')
SECRET_KEY = os.getenv('TOKOCRYPTO_SECRET_KEY')

# Konfigurasi Tokocrypto
exchange = ccxt.tokocrypto({
    'apiKey': API_KEY,
    'secret': SECRET_KEY,
})

# Pengaturan trading
symbol = 'BNB/USDT'               # Pasangan trading
interval = '5m'                   # Interval trading
amount_per_trade = 0.001          # Jumlah per perdagangan
grid_levels = 5                   # Jumlah level grid
grid_size = 0.01                  # Ukuran grid dalam persentase
trailing_sell_percent = 0.015     # Persentase trailing sell

# Target profit dan trailing sell canggih
TARGET_PROFIT = 10                # Target profit dalam persentase
ENABLE_TRAILING_SELL_ADVANCED = True
INITIAL_SELL_LO = -40             # Stoploss awal dalam persentase
TRAILING_SELL_ADJUSTMENT = 0.2    # Persentase penyesuaian trailing sell
