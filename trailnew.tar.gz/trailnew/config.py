import os
import ccxt

# API Tokocrypto
API_KEY = os.getenv('TOKOCRYPTO_API_KEY')
SECRET_KEY = os.getenv('TOKOCRYPTO_SECRET_KEY')

# Parameter trading
symbol = 'BNB/USDT'
interval = '5m'
amount_per_trade = 0.001
grid_levels = 5
grid_size = 0.01
trailing_sell_percent = 0.015  # Persentase trailing sell

# Inisialisasi pertukaran
exchange = ccxt.tokocrypto({
    'apiKey': API_KEY,
    'secret': SECRET_KEY,
})
