# python_bot.py

import pandas as pd
import time
import logging
from config import exchange, symbol, interval, amount_per_trade, grid_levels, grid_size, trailing_sell_percent, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED, INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT
from ml_model import train_svm_model, train_nn_model, predict_direction_combined

logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0
max_profit_loss = 0.0
current_sell_lo = INITIAL_SELL_LO

def check_usdt_balance():
    balance = exchange.fetch_balance()
    usdt_balance = balance.get('total', {}).get('USDT', 0)
    if usdt_balance < amount_per_trade * grid_levels:
        logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
        return False
    else:
        logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
        return True

def fetch_data():
    ohlcv = exchange.fetch_ohlcv(symbol, interval)
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df

def calculate_rsi(df, period=14):
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def place_grid_orders(df):
    last_price = df['close'].iloc[-1]
    grid_prices = [last_price * (1 + grid_size * i) for i in range(-grid_levels, grid_levels + 1)]
    for price in grid_prices:
        logging.info(f"Grid order ditempatkan pada harga: {price:.4f} USDT")

def update_trailing_sell_advanced(current_pl):
    global max_profit_loss, current_sell_lo
    if ENABLE_TRAILING_SELL_ADVANCED:
        if current_pl > max_profit_loss:
            max_profit_loss = current_pl
            current_sell_lo = (100 + INITIAL_SELL_LO) * (100 + max_profit_loss * TRAILING_SELL_ADJUSTMENT) / 100 - 100
            logging.info(f"Trailing sell diperbarui: Sell-lo baru pada {current_sell_lo}% berdasarkan P/L maksimum {max_profit_loss}%.")

    return current_sell_lo

def main():
    global total_profit
    if not check_usdt_balance():
        return

    df = fetch_data()
    df['RSI'] = calculate_rsi(df)
    model_svm, scaler_svm = train_svm_model(df)
    model_nn, scaler_nn = train_nn_model(df)

    logging.info("Memulai bot trading untuk pasangan %s", symbol)
    entry_price = None
    highest_price = 0

    while True:
        try:
            df = fetch_data()
            df['RSI'] = calculate_rsi(df)

            last_rsi = df['RSI'].iloc[-1]
            last_price = df['close'].iloc[-1]
            current_pl = (last_price - entry_price) / entry_price * 100 if entry_price else 0

            direction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df)
            if direction is not None:
                logging.info(f"Prediksi arah harga: {'Naik' if direction == 1 else 'Turun'}")

                if direction == 1 and last_rsi < 30:
                    logging.info(f"Membeli pada harga {last_price:.4f} USDT dengan RSI {last_rsi:.2f}")
                    entry_price = last_price
                    highest_price = last_price
                    place_grid_orders(df)
                elif direction == 0 or trailing_sell(last_price, highest_price, entry_price):
                    profit = last_price - entry_price if entry_price else 0
                    total_profit += profit
                    logging.info(f"Menjual pada harga {last_price:.4f} USDT dengan RSI {last_rsi:.2f}. Profit: {profit:.4f} USDT")
                    logging.info(f"Total Profit Keseluruhan: {total_profit:.4f} USDT")
                    entry_price = None

            if entry
