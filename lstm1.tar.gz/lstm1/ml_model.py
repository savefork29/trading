
# ml_model.py

import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from keras.models import Sequential
from keras.layers import Dense, LSTM

# Fungsi untuk melatih model SVM
def train_svm_model(data):
    features = data[['open', 'high', 'low', 'close', 'volume']].values
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(features)
    X = scaled_features[:-1]
    y = np.where(data['close'].shift(-1) > data['close'], 1, 0)[:-1]
    model = SVC()
    model.fit(X, y)
    return model, scaler

# Fungsi untuk melatih model LSTM
def train_lstm_model(data, lookback=60):
    features = data[['open', 'high', 'low', 'close', 'volume']].values
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(features)
    X, y = [], []
    for i in range(lookback, len(scaled_features)):
        X.append(scaled_features[i-lookback:i])
        y.append(1 if data['close'].iloc[i] > data['close'].iloc[i-1] else 0)
    X, y = np.array(X), np.array(y)
    model = Sequential()
    model.add(LSTM(units=50, return_sequences=True, input_shape=(X.shape[1], X.shape[2])))
    model.add(LSTM(units=50))
    model.add(Dense(units=1, activation='sigmoid'))
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    model.fit(X, y, epochs=5, batch_size=32)
    return model, scaler

# Fungsi untuk melakukan prediksi menggunakan SVM dan LSTM
def predict_direction_combined(model_svm, scaler_svm, model_lstm, scaler_lstm, data, lookback=60):
    features = data[['open', 'high', 'low', 'close', 'volume']].values
    scaled_features = scaler_lstm.transform(features)
    X_lstm = np.array([scaled_features[-lookback:]])
    lstm_prediction = model_lstm.predict(X_lstm)[0][0]
    scaled_features_svm = scaler_svm.transform(features)
    X_svm = scaled_features_svm[-1].reshape(1, -1)
    svm_prediction = model_svm.predict(X_svm)[0]
    combined_prediction = 1 if lstm_prediction > 0.5 or svm_prediction == 1 else 0
    return combined_prediction
