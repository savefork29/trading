
# config.py

# Pengaturan untuk API
API_KEY = 'your_api_key'
SECRET_KEY = 'your_secret_key'

# Pengaturan untuk trading
TRADE_SYMBOL = 'BTC/USDT'
TRADE_AMOUNT = 0.001  # Jumlah unit yang diperdagangkan per order

# Pengaturan untuk machine learning
LSTM_LOOKBACK = 60  # Jumlah candle historis yang digunakan LSTM (misalnya 60 untuk 60 candle terakhir)

# Parameter lainnya yang relevan dapat ditambahkan sesuai kebutuhan
