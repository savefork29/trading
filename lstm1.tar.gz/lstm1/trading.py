
# trading.py

import ccxt
import pandas as pd
import numpy as np
from config import API_KEY, SECRET_KEY, TRADE_SYMBOL, TRADE_AMOUNT, LSTM_LOOKBACK
from ml_model import train_svm_model, train_lstm_model, predict_direction_combined

# Menghubungkan dengan exchange
exchange = ccxt.tokocrypto({
    'apiKey': API_KEY,
    'secret': SECRET_KEY,
})

# Fungsi untuk mendapatkan data historis
def get_historical_data(symbol, timeframe='1m', limit=100):
    ohlcv = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    data = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    data['timestamp'] = pd.to_datetime(data['timestamp'], unit='ms')
    return data

# Menginisialisasi model
def initialize_models(data):
    model_svm, scaler_svm = train_svm_model(data)
    model_lstm, scaler_lstm = train_lstm_model(data, lookback=LSTM_LOOKBACK)
    return model_svm, scaler_svm, model_lstm, scaler_lstm

# Fungsi untuk melakukan prediksi dan keputusan trading
def make_trade_decision(data, model_svm, scaler_svm, model_lstm, scaler_lstm):
    prediction = predict_direction_combined(model_svm, scaler_svm, model_lstm, scaler_lstm, data, lookback=LSTM_LOOKBACK)
    if prediction is None:
        print("Tidak ada sinyal trading.")
    elif prediction == 1:
        print("Sinyal beli terdeteksi.")
        place_order('buy', TRADE_AMOUNT)
    else:
        print("Sinyal jual terdeteksi.")
        place_order('sell', TRADE_AMOUNT)

# Fungsi untuk menempatkan order pada exchange
def place_order(side, amount):
    try:
        if side == 'buy':
            order = exchange.create_market_buy_order(TRADE_SYMBOL, amount)
        else:
            order = exchange.create_market_sell_order(TRADE_SYMBOL, amount)
        print(f"Order {side} berhasil: {order}")
    except Exception as e:
        print(f"Error placing order: {e}")

# Fungsi utama trading loop
def trading_loop():
    data = get_historical_data(TRADE_SYMBOL)
    model_svm, scaler_svm, model_lstm, scaler_lstm = initialize_models(data)
    
    while True:
        try:
            data = get_historical_data(TRADE_SYMBOL)
            make_trade_decision(data, model_svm, scaler_svm, model_lstm, scaler_lstm)
        except Exception as e:
            print(f"Error dalam trading loop: {e}")

# Jalankan trading loop
if __name__ == '__main__':
    trading_loop()
