import pandas as pd
import time
import logging
from config import (
    exchange, PAIR_SYMBOL, interval, amount_per_trade, grid_levels, grid_size,
    trailing_sell_percent, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED,
    INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT, model_svm, model_neural_network
)
from ml_model import train_svm_model, train_nn_model, load_trained_models, predict_direction_combined

# Inisialisasi logging dengan level logging informasi
logging.basicConfig(level=logging.INFO)
logging.info("Memulai bot trading...")

total_profit = 0

def check_usdt_balance():
    try:
        balance = exchange.fetch_balance()
        usdt_balance = balance.get('total', {}).get('USDT', 0)
        if usdt_balance < amount_per_trade * grid_levels:
            logging.info(f"Saldo USDT tidak mencukupi: {usdt_balance} USDT. Tambahkan saldo untuk memulai trading.")
            return False
        else:
            logging.info(f"Saldo USDT mencukupi: {usdt_balance} USDT.")
            return True
    except Exception as e:
        logging.error(f"Error checking USDT balance: {e}")
        return False

def fetch_data():
    try:
        ohlcv = exchange.fetch_ohlcv(PAIR_SYMBOL, interval)
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        return df
    except Exception as e:
        logging.error(f"Error fetching data: {e}")
        return pd.DataFrame()  # Mengembalikan DataFrame kosong jika terjadi error

def calculate_rsi(df, period=14):
    try:
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    except Exception as e:
                logging.error(f"Error calculating RSI: {e}")
        return None

def place_order(order_type, amount):
    try:
        if order_type == 'buy':
            exchange.create_market_buy_order(PAIR_SYMBOL, amount)
            logging.info(f"Placed buy order for {amount} {PAIR_SYMBOL}.")
        elif order_type == 'sell':
            exchange.create_market_sell_order(PAIR_SYMBOL, amount)
            logging.info(f"Placed sell order for {amount} {PAIR_SYMBOL}.")
    except Exception as e:
        logging.error(f"Error placing order: {e}")

def execute_trading_strategy():
    global total_profit

    while True:
        if not check_usdt_balance():
            time.sleep(60)  # Tunggu 60 detik sebelum mencoba lagi
            continue

        df = fetch_data()
        if df.empty:
            logging.warning("Data frame is empty. Skipping trading iteration.")
            time.sleep(60)  # Tunggu 60 detik sebelum mencoba lagi
            continue

        # Menambahkan perhitungan RSI ke data
        df['RSI'] = calculate_rsi(df)
        if df['RSI'].isnull().values.any():
            logging.warning("RSI calculation returned NaN values. Skipping trading iteration.")
            time.sleep(60)  # Tunggu 60 detik sebelum mencoba lagi
            continue

        # Memanggil prediksi dari model machine learning
        prediction = predict_direction_combined(model_svm, None, model_neural_network, None, df, use_svm=True, use_nn=True)

        if prediction == 1:
            place_order('buy', amount_per_trade)
        elif prediction == 0:
            place_order('sell', amount_per_trade)

        # Penanganan keuntungan dan kerugian
        current_profit = ...  # Hitung profit saat ini
        total_profit += current_profit
        logging.info(f"Total profit saat ini: {total_profit}")

        time.sleep(60)  # Tunggu 60 detik sebelum iterasi berikutnya

if __name__ == "__main__":
    # Memuat model yang telah dilatih jika ada
    model_svm, scaler_svm, model_neural_network, scaler_nn = load_trained_models()

    # Memastikan model telah dimuat
    if model_svm is None and model_neural_network is None:
        logging.error("Tidak ada model yang dimuat. Pastikan untuk melatih model terlebih dahulu.")
    else:
        execute_trading_strategy()
