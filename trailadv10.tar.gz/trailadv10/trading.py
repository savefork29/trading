import pandas as pd
import time
import logging
from config import (
    exchange, PAIR_SYMBOL, interval, amount_per_trade, grid_levels, grid_size,
    trailing_sell_percent, TARGET_PROFIT, ENABLE_TRAILING_SELL_ADVANCED,
    INITIAL_SELL_LO, TRAILING_SELL_ADJUSTMENT,
    MODEL_SVM, MODEL_NEURAL_NETWORK  # Tambahkan import untuk pengaturan model
)
from ml_model import train_svm_model, train_nn_model, load_trained_models, predict_direction_combined

def calculate_rsi(df, period=14):
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def fetch_data():
    try:
        ohlcv = exchange.fetch_ohlcv(PAIR_SYMBOL, interval)
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        
        # Hitung RSI
        df['RSI'] = calculate_rsi(df)
        
        # Hitung ATR dan ADX (implementasi sederhana contoh)
        df['ATR'] = df['high'].rolling(window=14).max() - df['low'].rolling(window=14).min()  # Contoh penghitungan ATR
        df['ADX'] = df['close'].rolling(window=14).mean()  # Contoh penghitungan ADX
        
        return df
    except Exception as e:
        logging.error(f"Error fetching data: {e}")
        return pd.DataFrame()  # Mengembalikan DataFrame kosong jika terjadi error

def check_usdt_balance():
    balance = exchange.fetch_balance()
    usdt_balance = balance['total']['USDT']
    logging.info(f"Saldo USDT saat ini: {usdt_balance:.2f} USDT")
    return usdt_balance > 0

def trailing_sell(last_price, highest_price, entry_price):
    if ENABLE_TRAILING_SELL_ADVANCED:
        if last_price < highest_price * (1 - trailing_sell_percent / 100):
            try:
                exchange.create_market_sell_order(PAIR_SYMBOL, amount_per_trade)
                logging.info(f"Trailing sell executed at price: {last_price:.4f} USDT")
                return True
            except Exception as e:
                logging.error(f"Error executing trailing sell order: {e}")
    return False

def main():
    try:
        # Memuat model yang sudah dilatih atau melatih model baru jika belum tersedia
        model_svm, scaler_svm, model_nn, scaler_nn = load_trained_models()
        if model_svm is None or model_nn is None:
            logging.info("Model tidak ditemukan. Melatih model baru...")
            data = fetch_data()
            if data.empty:
                logging.error("Data tidak tersedia untuk melatih model.")
                return
            
            if MODEL_SVM:
                logging.info("Memulai pelatihan model SVM...")
                model_svm, scaler_svm = train_svm_model(data)
                logging.info("Pelatihan model SVM selesai.")

            if MODEL_NEURAL_NETWORK:
                logging.info("Memulai pelatihan model Neural Network...")
                model_nn, scaler_nn = train_nn_model(data)
                logging.info("Pelatihan model Neural Network selesai.")
        else:
            logging.info("Model yang ada telah dimuat.")

        # Cek saldo USDT
        if not check_usdt_balance():
            return

        highest_price = 0
        entry_price = 0

        while True:
            df = fetch_data()
            if df.empty or 'RSI' not in df.columns or 'ATR' not in df.columns or 'ADX' not in df.columns:
                logging.error("Data tidak valid atau tidak lengkap. Mencoba kembali...")
                time.sleep(60)
                continue

            last_price = df['close'].iloc[-1]
            rsi = df['RSI'].iloc[-1]  # Ambil nilai RSI terbaru

            # Update harga tertinggi untuk logika trailing sell
            highest_price = max(highest_price, last_price)

            # Prediksi arah harga
            combined_prediction = None
            if MODEL_SVM and MODEL_NEURAL_NETWORK:
                combined_prediction = predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df)
            elif MODEL_SVM:
                # Prediksi hanya menggunakan model SVM
                X_svm = scaler_svm.transform(df[['close', 'RSI', 'ATR', 'ADX']].iloc[-1:])
                combined_prediction = model_svm.predict(X_svm)[0]
            elif MODEL_NEURAL_NETWORK:
                # Prediksi hanya menggunakan model Neural Network
                X_nn = scaler_nn.transform(df[['open', 'high', 'low', 'close', 'volume', 'RSI', 'ATR', 'ADX']].iloc[-1:])
                nn_prediction = model_nn.predict(X_nn)
                combined_prediction = 1 if nn_prediction >= 0.5 else 0

            if combined_prediction is not None:
                if combined_prediction == 1 and entry_price == 0:
                    logging.info(f"Sinyal beli terdeteksi pada harga: {last_price:.4f} USDT. Menempatkan pesanan beli...")
                    try:
                        exchange.create_market_buy_order(PAIR_SYMBOL, amount_per_trade)
                        entry_price = last_price
                        logging.info(f"Pesanan beli dieksekusi pada harga: {last_price:.4f} USDT.")
                    except Exception as e:
                        logging.error(f"Error executing buy order: {e}")

                elif combined_prediction == 0 and entry_price > 0:
                    if trailing_sell(last_price, highest_price, entry_price):
                        entry_price = 0

            time.sleep(60)

    except Exception as e:
        logging.error(f"Error tak terduga dalam main loop: {e}")

if __name__ == "__main__":
    main()
