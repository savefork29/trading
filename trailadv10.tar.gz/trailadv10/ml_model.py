import pandas as pd
import numpy as np
import os
import joblib
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam

MODEL_SVM_PATH = 'svm_model.joblib'
SCALER_SVM_PATH = 'scaler_svm.joblib'
MODEL_NN_PATH = 'nn_model.keras'
SCALER_NN_PATH = 'scaler_nn.joblib'

# Fungsi untuk menghitung indikator tambahan
def calculate_indicators(data):
    data['ATR'] = data['close'].rolling(window=14).apply(lambda x: x.max() - x.min())
    data['MA20'] = data['close'].rolling(window=20).mean()
    data['UpperBand'] = data['MA20'] + 2 * data['close'].rolling(window=20).std()
    data['LowerBand'] = data['MA20'] - 2 * data['close'].rolling(window=20).std()
    data['ADX'] = data['close'].rolling(window=14).apply(lambda x: (x.diff().abs().sum() / 14) * 100)
    data['RSI'] = calculate_rsi(data['close'])  # Pastikan untuk menghitung RSI
    return data

# Fungsi untuk menghitung RSI
def calculate_rsi(close_prices, period=14):
    delta = close_prices.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

# Fungsi untuk melatih model SVM
def train_svm_model(data):
    data = calculate_indicators(data)
    data['PriceChange'] = data['close'].diff().shift(-1)
    data['PriceDirection'] = (data['PriceChange'] > 0).astype(int)
    data.dropna(inplace=True)

    # Fitur dan label untuk SVM
    X = data[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']]
    y = data['PriceDirection']

    scaler_svm = StandardScaler()
    X_scaled = scaler_svm.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # Buat dan latih model SVM
    model_svm = SVC(kernel='linear')
    model_svm.fit(X_train, y_train)

    # Simpan model dan scaler
    joblib.dump(model_svm, MODEL_SVM_PATH)
    joblib.dump(scaler_svm, SCALER_SVM_PATH)

    return model_svm, scaler_svm

# Fungsi untuk melatih model neural network
def train_nn_model(data):
    data = calculate_indicators(data)
    data.dropna(inplace=True)
    scaler_nn = StandardScaler()

    # Fitur dan target untuk neural network
    X = data[['open', 'high', 'low', 'close', 'volume', 'RSI', 'ATR', 'ADX']]
    data['target'] = (data['close'].shift(-1) > data['close']).astype(int)
    y = data['target'].dropna()

    # Memastikan ukuran yang sama antara X dan y
    min_len = min(len(X), len(y))
    X, y = X[:min_len], y[:min_len]

    X_scaled = scaler_nn.fit_transform(X)

    # Membagi data untuk pelatihan dan pengujian
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # Membangun model neural network sederhana
    model_nn = Sequential([
        Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
        Dropout(0.2),
        Dense(32, activation='relu'),
        Dense(1, activation='sigmoid')
    ])

    model_nn.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])
    model_nn.fit(X_train, y_train, epochs=30, batch_size=16, verbose=1)

    # Simpan model dan scaler
    model_nn.save(MODEL_NN_PATH)
    joblib.dump(scaler_nn, SCALER_NN_PATH)

    return model_nn, scaler_nn

# Fungsi untuk memuat model yang telah dilatih jika ada
def load_trained_models():
    if os.path.exists(MODEL_SVM_PATH) and os.path.exists(SCALER_SVM_PATH) and \
       os.path.exists(MODEL_NN_PATH) and os.path.exists(SCALER_NN_PATH):
        model_svm = joblib.load(MODEL_SVM_PATH)
        scaler_svm = joblib.load(SCALER_SVM_PATH)
        model_nn = load_model(MODEL_NN_PATH)
        scaler_nn = joblib.load(SCALER_NN_PATH)
        return model_svm, scaler_svm, model_nn, scaler_nn
    else:
        return None, None, None, None

# Fungsi untuk memprediksi arah harga menggunakan kombinasi model
def predict_direction_combined(model_svm, scaler_svm, model_nn, scaler_nn, df, use_svm, use_nn):
    df = calculate_indicators(df)
    last_rsi = df['RSI'].iloc[-1]
    last_adx = df['ADX'].iloc[-1]
    
    prediction_svm = None
    prediction_nn = None

    # Filter tambahan: Hanya prediksi saat ADX cukup kuat
    if last_adx > 20 and (last_rsi < 30 or last_rsi > 70):
        if use_svm:
            # SVM prediksi
            X_svm = scaler_svm.transform(df[['close', 'RSI', 'ATR', 'UpperBand', 'LowerBand', 'ADX']].iloc[-1:])
            prediction_svm = model_svm.predict(X_svm)[0]

        if use_nn:
            # Neural network prediksi
            X_nn = scaler_nn.transform(df[['open', 'high', 'low', 'close', 'volume', 'RSI', 'ATR', 'ADX']].iloc[-1:])
            nn_prediction = model_nn.predict(X_nn)
            prediction_nn = 1 if nn_prediction >= 0.5 else 0

    # Kombinasi prediksi
    combined_prediction = 0
    if prediction_svm == 1 and prediction_nn == 1:
        combined_prediction = 1
    elif prediction_svm == 0 and prediction_nn == 0:
        combined_prediction = 0
    return combined_prediction
