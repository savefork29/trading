# Konfigurasi Bot Trading

# API Exchange (contoh)
API_KEY = 'your_api_key'  # Ganti dengan API key Anda
API_SECRET = 'your_api_secret'  # Ganti dengan API secret Anda

# Parameter Trading
PAIR_SYMBOL = 'USDT/BTC'  # Pasangan trading yang digunakan
INTERVAL = '1m'  # Interval candle (1 menit)
AMOUNT_PER_TRADE = 0.01  # Jumlah yang akan diperdagangkan dalam USDT
GRID_LEVELS = 5  # Jumlah level grid untuk strategi grid trading
GRID_SIZE = 0.01  # Ukuran grid (selisih harga antar order)

# Konfigurasi Trailing Sell
TRAILING_SELL_PERCENT = 1.0  # Persentase untuk trailing sell
ENABLE_TRAILING_SELL_ADVANCED = True  # Aktifkan trailing sell canggih
INITIAL_SELL_LO = 0.05  # Persentase awal untuk menjual (level awal)
TRAILING_SELL_ADJUSTMENT = 0.02  # Penyesuaian trailing sell

# Konfigurasi Machine Learning
USE_SVM = True  # Menggunakan model SVM
USE_NN = True  # Menggunakan Neural Network
MODEL_PATH_SVM = 'path_to_your_svm_model'  # Path ke model SVM
MODEL_PATH_NN = 'path_to_your_nn_model'  # Path ke model Neural Network
LOAD_PREVIOUS_MODEL = True  # Menggunakan model yang sudah dilatih sebelumnya

# Logging
LOG_FILE = 'trading_bot.log'  # Nama file log untuk mencatat aktivitas bot
LOG_LEVEL = 'INFO'  # Tingkat log (INFO, WARNING, ERROR)
