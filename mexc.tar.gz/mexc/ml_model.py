import numpy as np
import pandas as pd
import yfinance as yf
import pandas_ta as ta
from sklearn.preprocessing import MinMaxScaler
from keras.models import Model
from keras.layers import LSTM, Dense, Input, Activation
from keras import optimizers

# 1. Mengunduh data dan menambahkan indikator
data = yf.download(tickers='^RUI', start='2012-03-11', end='2022-07-10')
data['RSI'] = ta.rsi(data.Close, length=15)
data['EMAF'] = ta.ema(data.Close, length=20)
data['EMAM'] = ta.ema(data.Close, length=100)
data['EMAS'] = ta.ema(data.Close, length=150)
data['Target'] = data['Adj Close'] - data.Open
data['Target'] = data['Target'].shift(-1)
data['TargetClass'] = [1 if data.Target[i] > 0 else 0 for i in range(len(data))]
data['TargetNextClose'] = data['Adj Close'].shift(-1)
data.dropna(inplace=True)
data.reset_index(inplace=True)
data.drop(['Volume', 'Close', 'Date'], axis=1, inplace=True)

# 2. Skalasi data
scaler = MinMaxScaler(feature_range=(0, 1))
data_set_scaled = scaler.fit_transform(data.iloc[:, :11].values)

# 3. Menyiapkan input untuk LSTM
X, y = [], []
backcandles = 30
for i in range(backcandles, data_set_scaled.shape[0]):
    X.append(data_set_scaled[i-backcandles:i, :-1])  # semua kecuali kolom target
    y.append(data_set_scaled[i, -1])  # kolom target

X, y = np.array(X), np.array(y)
y = np.reshape(y, (len(y), 1))

# 4. Membagi data menjadi pelatihan dan pengujian
splitlimit = int(len(X) * 0.8)
X_train, X_test = X[:splitlimit], X[splitlimit:]
y_train, y_test = y[:splitlimit], y[splitlimit:]

# 5. Membangun model LSTM
lstm_input = Input(shape=(backcandles, X.shape[2]), name='lstm_input')
inputs = LSTM(150, name='first_layer')(lstm_input)
inputs = Dense(1, name='dense_layer')(inputs)
output = Activation('linear', name='output')(inputs)
model = Model(inputs=lstm_input, outputs=output)

# 6. Kompilasi dan pelatihan model
adam = optimizers.Adam()
model.compile(optimizer=adam, loss='mse')
model.fit(x=X_train, y=y_train, batch_size=15, epochs=30, shuffle=True, validation_split=0.1)

# 7. Menyimpan model ke dalam file .h5
model.save("lstm_model.h5")
print("Model berhasil disimpan sebagai lstm_model.h5")
